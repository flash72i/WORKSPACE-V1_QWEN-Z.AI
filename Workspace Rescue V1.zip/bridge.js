/* Мост между страницей (MAIN-мир) и фоном расширения.
   1) Возвращает панель по клику на иконку.
   2) Проксирует запросы «мимо CORS» через фоновый скрипт (байты и размеры).
      Крупные файлы фон отдаёт кусками по Range — параметр диапазона идёт релеем.
   3) ВОССТАНОВЛЕНИЕ ЗАКРЕПЛЁННОЙ ПАНЕЛИ: мост внедряется автоматически
      (content_scripts в manifest) и, если пользователь ранее закрепил панель
      (флаг в localStorage), просит фон внедрить content.js — панель переживает F5
      даже на сайтах со строгим CSP. Запасной путь — вставка тега
      <script src="chrome-extension://…/content.js"> (web_accessible_resources).
      Если флага нет — мост НЕ выполняет никакого кода на странице.
   Защита от двойного внедрения (клик по иконке + content_scripts): флаг ниже;
   сам content.js тоже не переустанавливается — он сверяет номер сборки. */

if (!window.__wzrBridge) {
  window.__wzrBridge = true;

  /* Сообщение в фон. Возвращает null, если фон недоступен (расширение обновили,
     контекст страницы устарел) — вызывающий решает, что делать. */
  function ask(msg) {
    return new Promise(resolve => {
      try {
        chrome.runtime.sendMessage(msg, resp => {
          if (chrome.runtime.lastError) { resolve(null); return; }
          resolve(resp || null);
        });
      } catch (e) { resolve(null); }
    });
  }

  chrome.runtime.onMessage.addListener((m) => {
    if (m && m.type === 'wzr-show') window.dispatchEvent(new CustomEvent('wzr:show'));
  });

  /* приветствие: страница узнаёт, что расширение на месте (обход CORS доступен) */
  function hello() { window.dispatchEvent(new CustomEvent('wzr:hello')); }
  hello();
  window.addEventListener('wzr:ping', hello);

  /* универсальный релей: страница шлёт событие-запрос, мост — в фон, ответ обратно */
  function relay(reqEv, resEv, msgType) {
    window.addEventListener(reqEv, (ev) => {
      const d = ev.detail || {};
      const id = d.id;
      const done = (detail) => window.dispatchEvent(new CustomEvent(resEv, { detail }));
      ask({ type: msgType, url: d.url, range: d.range })
        .then(resp => done(Object.assign({ id }, resp || { ok: false })))
        .catch(err => done({ id, ok: false, err: String(err) }));
    });
  }
  relay('wzr:fetchreq', 'wzr:fetchres', 'wzr-fetch');
  relay('wzr:sizereq', 'wzr:sizeres', 'wzr-size');

  /* --- авто-восстановление закреплённой панели после обновления страницы --- */
  function dockWanted() {
    try {
      const raw = localStorage.getItem('__wzrV1_ui') || localStorage.getItem('__wzr20_ui');
      const ui = raw ? JSON.parse(raw) : null;
      return !!(ui && ui.dock);
    } catch (e) { return false; }   // нет доступа к localStorage — ничего не делаем
  }
  function injectByTag() {
    try {
      const s = document.createElement('script');
      s.src = chrome.runtime.getURL('content.js');
      s.onload = () => s.remove();
      s.onerror = () => s.remove();
      (document.head || document.documentElement).appendChild(s);
    } catch (e) { /* контекст расширения устарел — панель поднимется после F5 в новой сессии */ }
  }
  function restore() {
    if (!dockWanted()) return;
    ask({ type: 'wzr-inject' }).then(resp => {
      if (!resp || !resp.ok) injectByTag();     // фон недоступен — пробуем тегом
    });
  }
  restore();
}
