/* ============================================================================
   workspace_manager.js  (V1)  —  файловый менеджер рабочей области чата
   ----------------------------------------------------------------------------
   САЙТЫ: chat.qwen.ai (готовый пресет) · chat.z.ai (готовый пресет) ·
   любые другие (авторежим с ловлей шаблона ссылки).

   НОВОЕ В ВЕРСИИ V1 (первый публичный релиз; включает всё из v19/v20):
     1. ПРОИЗВОДИТЕЛЬНОСТЬ: сборка ZIP (CRC32 + упаковка) вынесена в Web Worker —
        интерфейс сайта не подтормаживает даже на сотнях МБ. Дерево перерисовывается
        только при реальных изменениях; сканирование трафика инкрементальное;
        автообновление выполняется в requestIdleCallback (в «паузах» страницы).
     2. СОСТОЯНИЕ ПАПОК СОХРАНЯЕТСЯ: «ОТМЕТИТЬ ВСЁ» / «СНЯТЬ ВСЁ» / фильтр /
        автообновление больше НЕ разворачивают свёрнутые папки.
     3. РАЗМЕРЫ: у каждого файла справа виден размер; у папок — сумма размеров
        вложенных файлов (≈ если известны не все). Размеры берутся из ответов API,
        а при необходимости добираются HEAD/Range-запросами (настройка в «Настройках»).
     4. КОНТЕКСТНОЕ МЕНЮ (правый клик по файлу): «Открыть в новой вкладке»
        (текст/HTML/картинки/PDF браузер покажет прямо во вкладке),
        «Копировать прямую ссылку», «Скачать файл», «Копировать путь».
     5. СТРЕЛКИ ПАПОК рисуются собственные (▸/▾) — отображаются одинаково на
        любом сайте, включая chat.z.ai, чей CSS раньше глушил системные маркеры.
     6. КНОПКА «ОБНОВИТЬ» исправлена (раньше клик по ней считался «тихим»
        автообновлением и не выводил результат в лог).
     7. ИМЯ ZIP — по содержимому: одна папка → «имя_папки.zip», один файл →
        «имя_файла.zip», несколько корней → «rescue_ГГГГ-ММ-ДД_ЧЧММ.zip».
        Части больших архивов: «имя_part2.zip», …
     8. ОБЩИЙ РАЗМЕР ОТМЕЧЕННОГО показывается в строке статистики (≈ при
        неполных данных) и в подсказке кнопки «СКАЧАТЬ ZIP».
     9. ЛОГ БЕЗ ШУМА: автообновление пишет только «появился новый файл: …» —
        и больше ничего. Служебные сообщения — только при ручном ОБНОВИТЬ.
    10. «СТОП» отменяет всё МГНОВЕННО: прерываются идущие запросы (AbortController),
        начатый архив НЕ сохраняется, ничего не скачивается.
    11. ДВЕ ВКЛАДКИ: «ГЛАВНАЯ» и «НАСТРОЙКИ». Диагностика (СЫРОЙ ТРАФИК,
        КОПИРОВАТЬ ТРАФИК/ДИАГН./ЛОГ) перенесена в «Настройки».
    12. КНОПКА-СКРЕПКА 📎 в шапке: закрепляет панель у левого/правого края во всю
        высоту экрана. Закрепление запоминается и переживает обновление страницы
        (расширение само восстановит закреплённую панель).
    13. Нет личных данных — можно свободно распространять.
    14. В «Настройках» — кнопки быстрого открытия chat.qwen.ai и chat.z.ai.
    15. В «Настройках» — описание: суть программы и её преимущества.
    16. ШКАЛА ПАМЯТИ рабочей области: занято / всего / свободно (общий объём
        определяется из API или задаётся вручную в настройках).
    17. Совместимость: Chrome 111+ и Яндекс Браузер (Chromium 111+); при отсутствии
        world:"MAIN" расширение внедряет скрипт запасным способом (см. background.js).
    18. БЕЗ ОГРАНИЧЕНИЙ ПО ОБЪЁМУ: архивы автоматически делятся на части
        (900 МБ / 6000 файлов), а одиночные файлы крупнее 700 МБ сохраняются
        отдельными файлами мимо ZIP — скачивается всё, любого размера.
    19. БОКОВАЯ ПАНЕЛЬ КАК В FlowPick: по клику на иконку панель встаёт СПРАВА
        во всю высоту и «отделяется» от страницы (контент сайта сдвигается).
        Внутренний край панели тянется мышью — ширина меняется. Скрепка
        (теперь аккуратная SVG-кнопка) по-прежнему крепит/открепляет.
    20. КНОПКИ ВСЕГДА ВИДНЫ: нижняя панель кнопок зафиксирована и не уходит
        за экран даже при тысячах файлов — дерево скроллится внутри.
    21. ПРОГРЕСС-БАР скачивания: фаза («скачано N из M», «сборка ZIP в фоне…»),
        больше не нужно гадать, идёт загрузка или зависло.
    22. ИМЯ ZIP — по ОБЩЕЙ папке выделения: скачали вложенную папку «3» —
        архив назовётся «3.zip», а не по верхнему уровню «1».
    23. РАЗМЕРЫ ТОЧНЕЕ: ответы с чужим content-type (JSON-ошибка или
        HTML-заглушка вместо файла) больше не принимаются за размер —
        одинаковые «137 Б» у всех файлов исчезли.
    24. РУССКИЙ ЯЗЫК при просмотре во вкладке: текстовые blob-файлы открываются
        с charset=utf-8 — кириллица без «иероглифов».
    25. КОНТЕКСТНОЕ МЕНЮ ПАПКИ: «Оглавление папки» (страница-список с прямыми
        ссылками), «Страница чата», копирование пути, отметка/снятие.
    26. СОРТИРОВКА ДЕРЕВА (кнопка у фильтра): по алфавиту / по размеру /
        как отдал сервер. Кнопка «СЫРОЙ ТРАФИК» убрана — вся диагностика
        (состояние, источники, последние запросы, ошибки) в «КОПИРОВАТЬ ДИАГН.».

   ИСПРАВЛЕНО В 1.1.0 (аудит проекта):
     + СМЕНА ЧАТА ЧИСТИТ СОСТОЯНИЕ: файлы, размеры, ссылки и перехваченный трафик
       прошлого чата больше не «переезжают» в новый (раньше дерево показывало
       файлы предыдущего чата, пока не подтянется новый список).
     + ВОССТАНОВЛЕНИЕ ПАНЕЛИ после F5 идёт через фон (scripting), а не вставкой
       тега: работает и на сайтах, где CSP запрещает внешние скрипты.
     + Z.AI: режим (чат или публичная ссылка) определяется сразу, поэтому «АРХИВ
       ВСЕЙ ОБЛАСТИ», прямые ссылки и размеры работают даже если список пуст.
     + КРУПНЫЕ ФАЙЛЫ с чужого CDN: обход CORS качает их кусками (Range), а не
       одним сообщением — прежнее ограничение по размеру снято.
     + ПАМЯТЬ: сборка ZIP отдаёт буферы в воркер без копии (архивы до 900 МБ
       больше не требуют двойного объёма), кэш blob-ссылок ограничен, а откат
       при падении воркера перезапрашивает файлы вместо записи битого архива.
     + СКОРОСТЬ: автообновление больше не разбирает JSON всего трафика заново
       (кэш по источникам), поиск шаблона ссылки идёт по индексу, а не перебором.
     + МЕЛОЧИ: текст в логе выделяется мышью; кнопка сортировки подписана
       «СОРТ: …»; «СТОП» прерывает и запросы размеров; «УЗНАТЬ РАЗМЕРЫ СЕЙЧАС»
       перепроверяет файлы, размер которых определить не удалось.
   ДОБАВЛЕНО В 1.1.0 (по заявкам):
     + РАЗМЕРЫ НА Z.AI: их API не отдаёт размер списком, поэтому берём его
       из ответа на запрос содержимого (только заголовок, тело гасим).
     + ИТОГ ПО ВСЕМ ОТМЕЧЕННЫМ: строка «отмечено …» теперь считает все выбранные
       файлы, а не только попавшие под фильтр; при фильтре рядом видно, сколько
       из них в текущем отборе.
     + ЗАКРЫТИЕ ПАНЕЛИ ЗАПОМИНАЕТСЯ: нажали «×» — после F5 панель сама больше
       не появляется; вернуть её можно кликом по иконке.
     + КОМПАКТНЫЕ КНОПКИ ОТМЕТКИ: «☑ / ☐» вместо длинных надписей — поле фильтра
       больше не сжимается.
     + ЦВЕТНОЙ ЖУРНАЛ: ошибки красным, новые файлы жёлтым, сохранения зелёным.
     + ОБЩИЙ ОБЪЁМ ОБЛАСТИ: если API отдаёт лимит в ГБ/МБ — шкала его подхватит.
   ========================================================================== */
(function () {
  'use strict';
  /* Версию меняем только при несовместимых изменениях интерфейса.
     При загрузке НОВОЙ сборки панель пересоздаётся сама, без F5 (см. в конце). */
  const WZR_BUILD = '1.1.9';
  try { console.info('WORKSPACE V1: загружена сборка ' + WZR_BUILD); } catch (e) {}
  let DEAD = false;                      // после выгрузки всё замолкает
  /* AbortError — штатная ситуация (СТОП, таймауты, отмена чтения): не засоряем консоль */
  addEventListener('unhandledrejection', e => {
    try { if (e && e.reason && (e.reason.name === 'AbortError' || /aborted/i.test(e.reason.message || ''))) e.preventDefault(); } catch (err) {}
  });
  const was = window.__wzrBuild;
  window.__wzrV1 = true;
  window.__wzrBuild = WZR_BUILD;
  if (was === WZR_BUILD) {
    /* Повторное внедрение (клик по иконке, автовосстановление после F5) — это не
       ошибка: панель уже стоит. Показываем её, если она была скрыта, и молча
       выходим, чтобы не сыпать предупреждениями в консоль сайта. */
    try { window.dispatchEvent(new CustomEvent('wzr:show')); } catch (e) {}
    return;
  }
  if (was) console.info('WORKSPACE: сборка ' + was + ' -> ' + WZR_BUILD + ', панель переустанавливается без F5');
  /* снять панель прошлой сборки, чтобы не осталось двух панелей */
  try {
    const old = document.getElementById('wzrPanel');
    if (old) old.remove();
    const ocm = document.getElementById('wzrCM'); if (ocm) ocm.remove();
    const ost = [...document.querySelectorAll('style')].find(s => s.textContent && s.textContent.includes('#wzrPanel'));
    if (ost) ost.remove();
  } catch (e) {}

  /* --------------------------- собственные стили --------------------------- */
  const ST = document.createElement('style');
  ST.textContent =
    '#wzrPanel,#wzrPanel *{box-sizing:border-box}' +
    '#wzrPanel button{appearance:auto!important;-webkit-appearance:button!important;background:#1a2130!important;' +
    'color:#e8eaf0!important;border:1px solid #33405a!important;border-radius:6px!important;padding:5px 10px!important;' +
    'font:600 13.5px/1.2 monospace!important;cursor:pointer!important;margin:0!important;text-transform:none!important;' +
    'box-shadow:none!important;letter-spacing:0!important;opacity:1!important;visibility:visible!important;display:inline-block!important}' +
    '#wzrPanel button:hover{background:#22304a!important}' +
    '#wzrPanel button.wzrGo{background:#1d5c2c!important;border-color:#2f8a44!important;color:#eaffea!important}' +
    '#wzrPanel button.wzrX{background:#4a1d1d!important;border-color:#8a2f2f!important;color:#ffeaea!important}' +
    '#wzrPanel button.wzrPinned{background:#1d5c2c!important;border-color:#2f8a44!important}' +
    '#wzrPanel button.wzrHide{display:none!important}' +
    '#wzrPanel input,#wzrPanel textarea,#wzrPanel select{background:#0d0d16!important;color:#eee!important;border:1px solid #2c2c40!important;' +
    'border-radius:4px!important;font:13.5px monospace!important;padding:3px 6px!important;user-select:text!important}' +
    '#wzrPanel textarea{cursor:text}' +
    '#wzrPanel label{color:#eee}' +
    /* дерево: строки, размеры, стрелки — всё своё, не зависит от CSS сайта */
    '#wzrPanel details{display:block!important;margin:0!important;padding:0!important;background:none!important;border:0!important}' +
    '#wzrPanel summary{display:flex!important;align-items:center;gap:4px;list-style:none!important;cursor:pointer;padding:1px 2px!important;' +
    'margin:0!important;background:none!important;border:0!important;color:#eee!important;font:inherit!important}' +
    '#wzrPanel summary::-webkit-details-marker{display:none!important}' +
    '#wzrPanel summary::marker{content:""!important}' +
    '#wzrPanel .wzrArw{display:inline-block;width:12px;flex:0 0 12px;text-align:center;color:#8fb7ff;font:12px monospace;transition:transform .12s}' +
    '#wzrPanel details[open]>summary .wzrArw{transform:rotate(90deg)}' +
    '#wzrPanel .wzrRow{display:flex;align-items:center;gap:4px;padding:1px 2px}' +
    '#wzrPanel .wzrRow:hover{background:#1c2436}' +
    '#wzrPanel .wzrNm{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:0 1 auto;min-width:24px}' +
    '#wzrPanel .wzrSz{margin-left:auto;flex:0 0 auto;padding-left:8px;color:#9adc9a;font-size:12.5px;white-space:nowrap;opacity:.85}' +
    /* вкладки */
    '#wzrPanel .wzrTabs{display:flex;gap:4px;padding:6px 10px 0}' +
    '#wzrPanel .wzrTab{flex:1;text-align:center!important}' +
    '#wzrPanel .wzrTabOn{background:#24405e!important;border-color:#4a6ea0!important;color:#dceaff!important}' +
    /* память */
    '#wzrPanel #memTxt{color:#9ad;font-size:13px;margin:4px 0 2px}' +
    '#wzrPanel #memBar{height:7px;background:#0d0d16;border:1px solid #2c2c40;border-radius:4px;overflow:hidden}' +
    '#wzrPanel #memFill{height:100%;width:0;background:#3aa757;transition:width .3s}' +
    /* настройки */
    '#wzrPanel .wzrSec{border:1px solid #2c2c40;border-radius:6px;padding:7px 9px;margin-bottom:7px;background:#11111c}' +
    '#wzrPanel .wzrSec>b{color:#8fb7ff}' +
    '#wzrPanel .wzrAbout{margin:4px 0 0;padding-left:16px;color:#cfd6e4}' +
    '#wzrPanel .wzrAbout li{margin:2px 0}' +
    /* контекстное меню */
    '#wzrCM{position:fixed;z-index:2147483647;background:#1c1c2c;border:1px solid #44446a;border-radius:6px;' +
    'box-shadow:0 6px 20px rgba(0,0,0,.6);padding:4px;display:none;min-width:220px;font:14px/1.3 monospace;user-select:none}' +
    '#wzrCM .wzrCMi{padding:5px 9px;border-radius:4px;cursor:pointer;color:#eee;white-space:nowrap}' +
    '#wzrCM .wzrCMi:hover{background:#2c3c5c}' +
    /* закреплённая панель (геометрию задаёт applyDock инлайном, чтобы «—» мог свернуть) */
    '#wzrPanel.docked{border-radius:0!important}' +
    '#wzrPanel.docked #bodyMain{display:flex;flex-direction:column;flex:1;min-height:0}' +
    /* ДЕРЕВО — единственная прокручиваемая часть панели. Оно занимает всё
       свободное место между панелью инструментов и строкой статистики, поэтому
       список файлов всегда доходит до нижней панели с кнопками, а сама нижняя
       панель не сдвигается (ни при 10 файлах, ни при 1000). */
    '#wzrPanel #tree{flex:1 1 0!important;min-height:0!important;max-height:none!important}' +
    /* память и строка состояния уступают место дереву в низком окне */
    '#wzrPanel #mem,#wzrPanel #c{flex:0 1 auto!important;min-height:0!important;overflow:hidden}' +
    /* кнопка-скрепка (SVG), прогресс-бар, грип ширины, нижняя панель кнопок */
    '#wzrPanel #pin{display:inline-flex!important;align-items:center;justify-content:center;padding:5px 8px!important}' +
    '#wzrPanel #pin svg{fill:currentColor;transform:rotate(45deg);transition:transform .15s}' +
    '#wzrPanel #pin.wzrPinned svg{transform:rotate(0)}' +
    '#wzrPanel #prog{display:none;margin:0 0 6px;flex:0 0 100%}' +
    '#wzrPanel #progTxt{color:#9ad;font-size:13px;margin-bottom:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}' +
    '#wzrPanel #progBar{height:8px;background:#0d0d16;border:1px solid #2c2c40;border-radius:4px;overflow:hidden}' +
    '#wzrPanel #progFill{height:100%;width:0;background:linear-gradient(90deg,#2f8a44,#7fd67f);transition:width .2s}' +
    '#wzrPanel #progFill.ind{width:40%!important;background:linear-gradient(90deg,#22304a,#8fb7ff,#22304a);background-size:200% 100%;animation:wzrSlide 1.1s linear infinite;transition:none}' +
    '@keyframes wzrSlide{from{background-position:0 0}to{background-position:-200% 0}}' +
    '#wzrPanel #grip{position:absolute;top:0;bottom:0;width:8px;cursor:ew-resize;z-index:5}' +
    '#wzrPanel #grip:hover{background:rgba(143,183,255,.22)}' +
    '#wzrPanel #gripL{position:absolute;top:0;bottom:0;left:-4px;width:8px;cursor:ew-resize;z-index:5}' +
    '#wzrPanel .wzrCorner{position:absolute;width:16px;height:16px;z-index:7}' +
    '#wzrPanel #gripBR{right:0;bottom:0;cursor:nwse-resize}' +
    '#wzrPanel #gripBL{left:0;bottom:0;cursor:nesw-resize}' +
    '#wzrPanel .wzrCorner:hover{background:rgba(143,183,255,.22)}' +
    '#wzrPanel.docked .wzrCorner,#wzrPanel.wzrCollapsed .wzrCorner{display:none!important}' +
    '#wzrPanel #gripL:hover{background:rgba(143,183,255,.22)}' +
    '#wzrPanel #gripB{position:absolute;left:10px;right:10px;bottom:0;height:7px;cursor:ns-resize;z-index:6;border-radius:0 0 8px 8px}' +
    '#wzrPanel #gripB:hover{background:rgba(143,183,255,.22)}' +
    '#wzrPanel #foot{border-top:1px solid #2c2c40;margin-top:8px;padding-top:8px;display:flex;flex-wrap:wrap;gap:5px;flex:0 0 auto;position:relative;z-index:2;background:#151521}' +
    /* --- ЖЁСТКАЯ РАСКЛАДКА: !important, чтобы правила сайта не ломали панель --- */
    '#wzrPanel #bodyMain{display:flex!important;flex-direction:column!important;flex:1 1 0!important;min-height:0!important;overflow:hidden!important}' +
    '#wzrPanel #tree{flex:1 1 auto!important;min-height:0!important;max-height:none!important;overflow-y:auto!important}' +
    '#wzrPanel #stat{flex:0 0 auto!important}' +
    '#wzrPanel #mem,#wzrPanel #c{flex:0 0 auto!important}' +
    '#wzrPanel .wzrLog{height:88px!important;max-height:88px!important;min-height:88px!important;overflow:auto!important;flex:0 0 auto!important}' +
    '#wzrPanel #foot{display:flex!important;flex-wrap:wrap!important;flex:0 0 auto!important}' +
    /* --- средний масштаб --- */
    '#wzrPanel.wzrFontMd{font:13.5px/1.45 monospace!important}' +
    '#wzrPanel.wzrFontMd button{font:600 12.5px/1.2 monospace!important}' +
    '#wzrPanel.wzrFontMd input,#wzrPanel.wzrFontMd textarea,#wzrPanel.wzrFontMd select{font:12.5px monospace!important}' +
    '#wzrPanel.wzrFontMd .wzrArw{font:11px monospace!important}' +
    '#wzrPanel.wzrFontMd .wzrSz{font-size:11.5px!important}' +
    '#wzrPanel.wzrFontMd #memTxt,#wzrPanel.wzrFontMd #progTxt{font-size:12px!important}' +
    '#wzrPanel.wzrFontMd .wzrLog{font:12.5px/1.4 monospace!important}' +
    '#wzrPanel.wzrFontMd .wzrIconBtn{font-size:15px!important;width:30px!important;padding:5px 0!important}' +
    '#wzrPanel.wzrFontMd .wzrSec div{font-size:12.5px!important}' +
    '#wzrPanel.wzrFontMd .wzrTab{font:12.5px/1.2 monospace!important}' +
    /* --- мелкий масштаб --- */
    '#wzrPanel.wzrFontSm{font:12.5px/1.45 monospace!important}' +
    '#wzrPanel.wzrFontSm button{font:600 11.5px/1.2 monospace!important}' +
    '#wzrPanel.wzrFontSm input,#wzrPanel.wzrFontSm textarea,#wzrPanel.wzrFontSm select{font:11.5px monospace!important}' +
    '#wzrPanel.wzrFontSm .wzrArw{font:10px monospace!important}' +
    '#wzrPanel.wzrFontSm .wzrSz{font-size:10.5px!important}' +
    '#wzrPanel.wzrFontSm #memTxt,#wzrPanel.wzrFontSm #progTxt{font-size:11px!important}' +
    '#wzrPanel.wzrFontSm .wzrLog{font:11.5px/1.4 monospace!important}' +
    '#wzrPanel.wzrFontSm .wzrIconBtn{font-size:13px!important;width:26px!important;padding:5px 0!important}' +
    '#wzrPanel.wzrFontSm .wzrSec div{font-size:11.5px!important}' +
    '#wzrPanel.wzrFontSm .wzrTab{font:11.5px/1.2 monospace!important}' +
    /* --- свёрнутая панель: остаётся только зелёная шапка --- */
    '#wzrPanel.wzrCollapsed{height:auto!important;max-height:none!important}' +
    '#wzrPanel.wzrCollapsed .wzrTabs,#wzrPanel.wzrCollapsed #bodyMain,#wzrPanel.wzrCollapsed #bodySet,#wzrPanel.wzrCollapsed #gripB,#wzrPanel.wzrCollapsed #prog{display:none!important}' +
    /* переключение вкладок: селектор сильнее защитного display:flex!important */
    '#wzrPanel #bodyMain.wzrHidden,#wzrPanel #bodySet.wzrHidden{display:none!important}' +
    '#wzrPanel.wzrNoSizes [data-sz],#wzrPanel.wzrNoSizes [data-szd]{display:none!important}' +
    /* компактные кнопки отметки и цветной журнал */
    '#wzrPanel .wzrIconBtn{flex:0 0 auto!important;width:34px!important;padding:6px 0!important;text-align:center!important;font-size:17px!important}' +
    /* ЖУРНАЛ уступает место дереву: высоту считает layoutMain (жёсткое правило —
       сначала место файлам, потом журналу), а внизу он сжимается сам, но никогда
       не выдавливает нижнюю панель с кнопками за край экрана. */
    '#wzrPanel .wzrLog{height:88px;max-height:88px;min-height:0;overflow:auto;margin-top:6px;flex:0 0 auto;background:#0d0d16!important;border:1px solid #2c2c40!important;border-radius:4px!important;padding:4px 6px!important;font:13.5px/1.4 monospace!important;color:#cfd6e4;user-select:text!important}' +
    '#wzrPanel .wzrLog div{white-space:pre-wrap;word-break:break-word}' +
    '#wzrPanel .wzrErr{color:#ff8a8a!important}' +
    '#wzrPanel .wzrNew{color:#ffd479!important}' +
    '#wzrPanel .wzrOk{color:#8fe38f!important}';
  (document.head || document.documentElement).appendChild(ST);

  const HOST = location.hostname;
  const IS_QWEN = /(^|\.)chat\.qwen\.ai$/.test(HOST);
  const IS_ZAI = /(^|\.)chat\.z\.ai$/.test(HOST);
  const getChat = () => { const m = location.pathname.match(/\/c\/([0-9a-f-]{8,})/i); return m ? m[1] : null; };
  const qid = () => getChat() || (location.pathname.match(/\/s\/([0-9a-f-]{8,})/i) || [])[1] || null;
  const ASSET_EXT = /\.(js|css|mjs|map|woff2?|ttf|eot|svg|ico|manifest|webmanifest)(\?|$)/i;
  const FILE_EXT = /\.[A-Za-z0-9]{1,10}$/;
  const STOP_SEG = new Set(['api', 'v1', 'v2', 'v3', 'chat', 'chats', 'workspace', 'workspace-files',
    'files', 'file', 'download', 'content', 'raw', 'output', 'artifact', 'artifacts', 'attachment', 'attachments']);
  const TELEM = /blank\.gif|\/e\.gif|zcode\.|sdata\.chatglm|pd=zai|bt=er|google-analytics/i;
  const ZAI_WS = location.origin + '/api/v1/web-dev/workspaces';
  const zaiToken = () => { try { return localStorage.getItem('token') || ''; } catch (e) { return ''; } };
  let zaiMode = null, zaiId = null, zaiWsId = null;
  const zaiDiag = { lsStatus: null, lsBody: '', wake: [], token: false };
  let quotaHint = null;                       // {total,used,free} — если API отдал квоту

  /* --------------------- настройки UI (переживают F5) ---------------------- */
  const UI_KEY = '__wzrV1_ui', UI_KEY_OLD = '__wzr20_ui';
  let UI = { dock: 'right', tab: 'main', sizesMode: 'full', quotaGB: 0, sort: 'alpha', w: 0, h: 0, hidden: false };
  try {
    let s = JSON.parse(localStorage.getItem(UI_KEY) || 'null');
    /* раньше ширина упиралась в минимум 320 — такое значение считаем «не задано» */
    if (!s) s = JSON.parse(localStorage.getItem(UI_KEY_OLD) || 'null');   // миграция с прошлой версии
    if (s && typeof s === 'object') {
      UI = Object.assign(UI, s);
      if (!UI.sizesMode) UI.sizesMode = (s.autoSizes === false) ? 'off' : 'full';   // миграция с галочки
      delete UI.autoSizes;
      if (['full', 'off'].indexOf(UI.sizesMode) < 0) UI.sizesMode = 'full';
      if (UI.w === 320) UI.w = 0;                 // «застрявшая» минимальная ширина — сбрасываем
    }
  } catch (e) {}
  function saveUI() { try { localStorage.setItem(UI_KEY, JSON.stringify(UI)); } catch (e) {} }

  /* ------------------------- режим показа размеров ------------------------ */
  function showingSizes() { return (UI.sizesMode || 'full') !== 'off'; }
  function shownSizeOf(p) {
    const s = sizeOf(p);
    if (s == null || !showingSizes()) return null;
    return s;
  }
  /* применить режим: скрыть память, колонку размеров и кнопку ручного запроса */
  function applySizesMode(request) {
    const off = !showingSizes();
    try { P.classList.toggle('wzrNoSizes', off); } catch (e) {}
    const mem = $('#mem');
    if (mem) mem.style.display = off ? 'none' : '';
    const sn = $('#szNow');
    if (sn) sn.style.display = off ? 'none' : '';
    try { updateAllSizes(); stat(); updateMem(); } catch (e) {}
    if (request && !off) { NEG.clear(); idle(() => resolveSizes(false)); }
  }

  /* ------------------------------ перехваты ------------------------------- */
  const origFetch = window.fetch;
  const captured = new Map(), reqLog = [];
  const CAP_MAX = 80 * 1024 * 1024, CAP_ONE = 25 * 1024 * 1024;   // лимиты МЕТАДАННЫХ (не загрузок!)
  let capBytes = 0;
  function push(src, text) {
    if (capBytes > CAP_MAX || !text || text.length > CAP_ONE || captured.has(src)) return;
    capBytes += text.length;
    try { captured.set(src, JSON.parse(text)); } catch (e) {}
  }
  window.fetch = async function (...a) {
    const u = typeof a[0] === 'string' ? a[0] : (a[0] && a[0].url) || String(a[0]);
    reqLog.push(u); if (reqLog.length > 4000) reqLog.shift();
    const res = await origFetch.apply(this, a);
    try {
      const ct = res.headers.get('content-type') || '';
      const cl = +(res.headers.get('content-length') || 0);
      if (ct.includes('json') && !captured.has(u) && (!cl || cl < CAP_ONE))
        res.clone().text().then(t => push(u, t)).catch(() => {});
    } catch (e) {}
    return res;
  };
  const oOpen = XMLHttpRequest.prototype.open, oSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (m, u) { this.__u = String(u); reqLog.push(this.__u); if (reqLog.length > 4000) reqLog.shift(); return oOpen.apply(this, arguments); };
  XMLHttpRequest.prototype.send = function () {
    this.addEventListener('load', function () {
      try { if ((this.getResponseHeader('content-type') || '').includes('json') && !captured.has(this.__u)) push(this.__u, this.responseText); } catch (e) {}
    });
    return oSend.apply(this, arguments);
  };

  /* каналы ловли ссылки: performance, <a>, window.open, blob */
  const extraUrls = [];
  /* extraUrls хранит до 2000 последних адресов. Каждому потребителю (поиск путей
     и добыча CDN-ссылок) нужен только «свежий» хвост — держим два курсора,
     иначе буфер целиком перебирался на каждом обновлении. */
  const cursors = { discover: 0, harvest: 0 };
  function newExtraUrls(who) {
    if (extraUrls.length < cursors[who]) cursors[who] = 0;      // старые записи вытеснены
    const out = extraUrls.slice(cursors[who]);
    cursors[who] = extraUrls.length;
    return out;
  }
  function noteUrl(u, how) {
    if (!u || !/^https?:|^blob:/.test(u)) return;
    extraUrls.push({ u, how });
    if (extraUrls.length > 2000) {
      extraUrls.shift();
      if (cursors.discover > 0) cursors.discover--;
      if (cursors.harvest > 0) cursors.harvest--;
    }
  }
  const perfSeen = new Set();
  let perfIdx = 0;
  function pollPerf() {
    try {
      const es = performance.getEntriesByType('resource');
      if (es.length < perfIdx) perfIdx = 0;                 // буфер очистили — начать заново
      for (let i = perfIdx; i < es.length; i++) {
        const e = es[i];
        if (perfSeen.has(e.name)) continue;
        perfSeen.add(e.name);
        noteUrl(e.name, 'perf:' + e.initiatorType);
      }
      perfIdx = es.length;
    } catch (e) {}
  }
  const oClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () { try { noteUrl(this.href, 'a.click'); } catch (e) {} return oClick.apply(this, arguments); };
  document.addEventListener('click', e => {
    try { const a = e.target && e.target.closest && e.target.closest('a[href]'); if (a) noteUrl(a.href, 'a.dom'); } catch (err) {}
  }, true);
  const oWinOpen = window.open;
  window.open = function (u) { try { noteUrl(typeof u === 'string' ? u : (u && u.url), 'window.open'); } catch (e) {} return oWinOpen.apply(this, arguments); };
  /* blob-ссылки страницы: держим только самые свежие, иначе карта росла бы без
     предела и держала в памяти сотни мегабайт (это была утечка). */
  const BLOBS_MAX = 64;
  const blobs = new Map();
  const oCU = URL.createObjectURL;
  URL.createObjectURL = function (b) {
    const u = oCU.call(URL, b);
    try {
      if (b instanceof Blob && b.size < 64 * 1024 * 1024) {
        blobs.set(u, b);
        while (blobs.size > BLOBS_MAX) blobs.delete(blobs.keys().next().value);
      }
    } catch (e) {}
    return u;
  };

  /* --------------------------------- состояние ----------------------------- */
  let PATHS = [], URLMAP = new Map(), SIZEMAP = new Map(), NEG = new Set();
  /* Размеры из API часто приходят с коротким ключом («index.html» вместо «src/index.html»).
     Храним такие значения отдельно по имени файла: если имя уникально — размер
     подставляется в дерево, при конфликте имён значение помечается как спорное. */
  const SIZE_BY_NAME = new Map();
  const PROBE_WHY = {};                     // почему не удалось узнать размер (для журнала)
  let PROBE_BUDGET = 32 * 1024 * 1024;      // сколько байт максимум читаем за круг подсчёта
  const okSize = v => typeof v === 'number' && Number.isFinite(v) && v >= 0;
  function setSize(path, value) {
    if (!path || !okSize(value)) return;
    SIZEMAP.set(path, value);
    const name = path.split('/').pop();
    if (!name) return;
    const prev = SIZE_BY_NAME.get(name);
    if (prev === undefined) SIZE_BY_NAME.set(name, value);
    else if (prev !== value) SIZE_BY_NAME.set(name, null);   // неоднозначно — не используем
  }
  function sizeOf(p) {
    const own = SIZEMAP.get(p);
    if (okSize(own)) return own;
    const byName = SIZE_BY_NAME.get(p.split('/').pop());
    return okSize(byName) ? byName : null;
  }
  let TEMPLATE = null, SEL = new Set(), OPEN_DIRS = new Set(), firstRender = true;
  let STOP = false, busy = false, armed = -1, runAC = null, SILENT = false;
  let curDirSizes = new Map();
  const WORKERS = 6, SPLIT_BYTES = 900 * 1024 * 1024, SPLIT_COUNT = 6000, HUGE_BYTES = 700 * 1024 * 1024;

  /* --------------------------------- утилиты ------------------------------- */
  function human(n) {
    if (n == null || !isFinite(n)) return '';
    if (n < 1024) return n + ' Б';
    const u = ['КБ', 'МБ', 'ГБ', 'ТБ']; let i = -1;
    do { n /= 1024; i++; } while (n >= 1024 && i < u.length - 1);
    /* Math.round() возвращает ЧИСЛО, а у числа нет .replace: на файлах от 100 КБ
       падало всё обновление дерева («replace is not a function» в консоли).
       Приводим значение к строке. */
    const v = n >= 100 ? String(Math.round(n)) : n >= 10 ? n.toFixed(1) : n.toFixed(2);
    return v.replace(/\.0+$/, '') + ' ' + u[i];
  }
  const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  /* человекочитаемые ошибки: сначала по-русски, оригинал — в скобках */
  function errRu(msg) {
    const s = String(msg == null ? '' : msg);
    const map = [
      [/Failed to fetch|NetworkError|Load failed/i, 'сеть недоступна или запрос заблокирован'],
      [/aborted|abort/i, 'запрос отменён'],
      [/is not a function|is not defined|Cannot read propert/i, 'внутренняя ошибка разбора ответа сайта'],
      [/Unexpected token|not valid JSON|Unexpected end of JSON/i, 'ответ сайта не является JSON'],
      [/timeout|timed out/i, 'превышено время ожидания ответа'],
      [/CORS|cross-origin/i, 'браузер заблокировал запрос (CORS)'],
      [/HTTP 401|HTTP 403|\b40[13]\b/, 'нет доступа — войдите в аккаунт'],
      [/HTTP 404|\b404\b/, 'файл не найден (404)'],
      [/HTTP 429|\b429\b/, 'слишком много запросов (429) — сайт временно ограничил'],
      [/HTTP 5\d\d|\b5\d\d\b/, 'ошибка на сервере сайта'],
    ];
    for (const [re, ru] of map) if (re.test(s)) return ru + ' (' + s.slice(0, 90) + ')';
    return s.slice(0, 140);
  }
  /* только настоящие строки: API может отдать объект/число вместо пути —
     раньше это роняло refresh() с «.replace is not a function» */
  function normPath(p) {
    if (typeof p !== 'string') return '';
    p = p.trim().replace(/^\/+/, '').replace(/\/{2,}/g, '/').replace(/\/+$/, '');
    return (p && !TELEM.test(p) && !p.includes('\u0000')) ? p : '';
  }
  function newAbort() { const ac = new AbortController(); return ac; }
  const idle = cb => (window.requestIdleCallback ? requestIdleCallback(cb, { timeout: 4000 }) : setTimeout(cb, 60));

  /* --------------------- список путей из трафика страницы ------------------ */
  function relFromUrl(u) {
    try {
      const o = new URL(u, location.href);
      if (ASSET_EXT.test(o.pathname) || TELEM.test(u)) return null;
      if (!FILE_EXT.test(decodeURIComponent(o.pathname))) return null;
      const same = o.hostname === location.hostname;
      const hasChat = getChat() && u.includes(getChat());
      if (!same && !hasChat && !/workspace|files?|artifact|attachment|output/i.test(o.pathname + o.search)) return null;
      let seg = decodeURIComponent(o.pathname).split('/').filter(Boolean);
      while (seg.length && (STOP_SEG.has(seg[0].toLowerCase()) || seg[0] === getChat() || /^v\d+$/.test(seg[0]))) seg.shift();
      if (seg.length < 2) return null;
      return seg.join('/');
    } catch (e) { return null; }
  }
  function cleanUrl(raw) {
    try {
      const o = new URL(raw);
      for (const k of [...o.searchParams.keys()]) {
        if (/process|resize|thumb|watermark|x-oss/i.test(k) || /image\/resize|thumb|!\d+/i.test(o.searchParams.get(k) || '')) o.searchParams.delete(k);
      }
      return o.href;
    } catch (e) { return raw; }
  }
  /* Добыча CDN-ссылок Qwen. Раньше на каждом автообновлении заново разбирались
     ВСЕ перехваченные ответы (десятки мегабайт JSON) — это была основная
     нагрузка фона. Теперь каждый ответ разбирается один раз, результат копится
     в HARVEST, а наружу отдаётся и число новых ссылок. */
  const HARVEST = new Map(), harvestSeen = new Set();
  const CDN_RE = /https:\/\/cdn\.qwenlm\.ai\/[^\s"'())]+/g;
  function relFromCdn(raw) {
    try {
      const o = new URL(raw.replace(/\\u0026/g, '&'));
      const seg = decodeURIComponent(o.pathname).split('/').filter(Boolean);
      let i = 0;
      if (seg[0] === 'output') i = 1;
      if (/^[0-9a-f-]{20,}$/.test(seg[i] || '')) i++;
      const rel = seg.slice(i).join('/');
      return (rel && FILE_EXT.test(rel)) ? { rel, url: cleanUrl(o.href) } : null;
    } catch (e) { return null; }
  }
  function harvestFromJson(json, out) {
    let txt; try { txt = JSON.stringify(json); } catch (e) { return; }
    CDN_RE.lastIndex = 0;
    let m; while ((m = CDN_RE.exec(txt))) { const r = relFromCdn(m[0]); if (r) out.set(r.rel, r.url); }
    (function walk(n) {
      if (Array.isArray(n)) { n.forEach(walk); return; }
      if (!n || typeof n !== 'object') return;
      for (const k of Object.keys(n)) {
        const v = n[k];
        if (typeof v === 'string' && /(original|direct|full|source|raw)_?url$/i.test(k) && /^https?:/.test(v)) {
          const r = relFromCdn(v); if (r) out.set(r.rel, r.url);
        } else walk(v);
      }
    })(json);
  }
  function harvestQwen() {
    let added = 0;
    for (const [src, json] of captured) {
      if (harvestSeen.has(src)) continue;
      harvestSeen.add(src);
      const was = HARVEST.size;
      harvestFromJson(json, HARVEST);
      added += HARVEST.size - was;
    }
    pollPerf();
    for (const { u } of newExtraUrls('harvest')) {
      CDN_RE.lastIndex = 0;
      let m; while ((m = CDN_RE.exec(u))) {
        const r = relFromCdn(m[0]);
        if (r && !HARVEST.has(r.rel)) { HARVEST.set(r.rel, r.url); added++; }
      }
    }
    return { map: HARVEST, added };
  }
  const NAME_KEY = k => /(path|filepath|file_path|relative_path|full_path|name|filename|file_name)$/i.test(k);
  const URL_KEY = k => /(^|_)(url|download_url|cdn_url|file_url|src|href)$/i.test(k);
  const SIZE_KEY = k => /^(size|bytes|file_size|filesize|file_bytes|content_length|length)$/i.test(k);
  /* инкрементальное сканирование перехваченного JSON: каждый ответ смотрим один раз */
  const scannedSrc = new Set();
  const DISC_PATHS = new Set();
  function scanJsonForSizes(node, basePath) {
    (function walk(n) {
      if (Array.isArray(n)) { n.forEach(walk); return; }
      if (!n || typeof n !== 'object') return;
      const nk = Object.keys(n).find(NAME_KEY);
      if (nk && typeof n[nk] === 'string') {
        const rel = normPath(n[nk]);
        if (rel && FILE_EXT.test(rel)) {
          const sk = Object.keys(n).find(k => SIZE_KEY(k) && okSize(n[k]));
          if (sk) setSize(rel, n[sk]);
        }
      }
      for (const k of Object.keys(n)) walk(n[k]);
    })(node);
  }
  const QUOTA_BAD = /token|rate|rpm|tpm|retry|attempt|timeout|delay|count|width|height|duration|ms$|_ms/i;
  function scanQuota(j) {
    try {
      const num = v => (typeof v === 'number' && isFinite(v)) ? v : (typeof v === 'string' && /^\d{5,}$/.test(v) ? +v : null);
      (function walk(n) {
        if (!n || typeof n !== 'object') return;
        if (Array.isArray(n)) { n.forEach(walk); return; }
        for (const k of Object.keys(n)) {
          const v = num(n[k]);
          const storage = /(storage|workspace|disk|space|quota)/i.test(k);
          if (v != null && storage && /(_gb|_gib|gb)$/i.test(k) && v > 0 && v <= 100000) {
            /* лимит задан в гигабайтах — 10 ГБ и т.п. */
            quotaHint = quotaHint || { src: 'api' };
            quotaHint.total = Math.max(quotaHint.total || 0, v * 1073741824);
          } else if (v != null && storage && /(_mb|_mib|mb)$/i.test(k) && v > 0 && v <= 100000) {
            quotaHint = quotaHint || { src: 'api' };
            quotaHint.total = Math.max(quotaHint.total || 0, v * 1048576);
          } else if (v != null && v > 1e5 && !QUOTA_BAD.test(k)) {
            quotaHint = quotaHint || { src: 'api' };
            if (/total|quota|capacity|limit|max/i.test(k)) quotaHint.total = Math.max(quotaHint.total || 0, v);
            else if (/used/i.test(k)) quotaHint.used = Math.max(quotaHint.used || 0, v);
            else if (/free|available|remaining/i.test(k)) quotaHint.free = Math.max(quotaHint.free || 0, v);
          } else if (n[k] && typeof n[k] === 'object') walk(n[k]);
        }
      })(j);
    } catch (e) {}
  }
  function discover() {
    for (const [src, json] of captured) {
      if (scannedSrc.has(src)) continue;
      scannedSrc.add(src);
      scanJsonForSizes(json);
      scanQuota(json);
      (function walk(node) {
        if (Array.isArray(node)) { for (const x of node) { if (typeof x === 'string') { const rel = normPath(x); if (rel.includes('/') && FILE_EXT.test(rel) && !TELEM.test(rel)) DISC_PATHS.add(rel); } else walk(x); } return; }
        if (!node || typeof node !== 'object') return;
        const nk = Object.keys(node).find(NAME_KEY);
        if (nk && typeof node[nk] === 'string') {
          const rel = normPath(node[nk]);
          if (rel.includes('/') && FILE_EXT.test(rel)) {
            const uk = Object.keys(node).find(k => URL_KEY(k) && /^https?:/.test(node[k] || ''));
            DISC_PATHS.add(rel); if (uk && !URLMAP.has(rel)) URLMAP.set(rel, node[uk]);
            return;
          }
        }
        for (const k of Object.keys(node)) walk(node[k]);
      })(json);
    }
    pollPerf();
    for (const { u } of newExtraUrls('discover')) {
      const rel = relFromUrl(u);
      if (!rel) continue;
      DISC_PATHS.add(rel);
      if (/^https?:/.test(u) && !URLMAP.has(rel)) URLMAP.set(rel, u);
    }
    return { paths: [...DISC_PATHS].sort() };
  }

  function urlFor(p) {
    if (URLMAP.has(p)) return URLMAP.get(p);
    if (IS_QWEN && getChat()) return '/api/v2/chat/' + getChat() + '/' + p;
    if (IS_ZAI && zaiMode) return 'zai:' + p;
    if (TEMPLATE) return TEMPLATE.replace('{P}', p.split('/').map(encodeURIComponent).join('/'))
      .replace('{E}', encodeURIComponent(p)).replace('{R}', p);
    return null;
  }
  function absUrl(u) { try { return u.startsWith('http') ? u : new URL(u, location.href).href; } catch (e) { return u; } }

  /* Режим z.ai (обычный чат или публичная страница /s/…) нужен и до первого
     удачного списка: от него зависят прямые ссылки, размеры и серверный архив. */
  function setZaiTarget() {
    const ms = location.pathname.match(/\/s\/([0-9a-f-]{8,})/i);
    zaiMode = ms ? 'share' : 'chat';
    zaiId = ms ? ms[1] : getChat();
  }

  /* ---------- точный пресет Z.AI (найден в их frontend-бандле) ---------- */
  async function zaiWake() {
    const tok = zaiToken();
    const H = { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + tok };
    if (zaiMode === 'chat') {
      try {
        const ac = new AbortController(); const to = setTimeout(() => ac.abort(), 5000);
        const r = await fetch(location.origin + '/api/v1/web-dev/workspaces/up', { method: 'POST', signal: ac.signal,
          headers: { Accept: 'text/event-stream', 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + tok },
          body: JSON.stringify({ chatId: zaiId, workspace_id: zaiWsId || undefined }) });
        zaiDiag.wake.push('up:' + r.status);
        let rd = null;
        try { if (r.body) { rd = r.body.getReader(); await rd.read(); } } catch (e) {}
        clearTimeout(to);
        try { if (rd) await rd.cancel(); } catch (e) {}          // отменяем чтение, не рвём запрос
        rd = null;
      } catch (e) { zaiDiag.wake.push('up:' + (e.name || e.message)); }
    }
    if (zaiMode === 'chat') {
      try {
        const r = await fetch(location.origin + '/api/v1/chats/' + zaiId, { headers: H });
        if (r.ok) { const j = await r.json(); const b = j && j.chat && j.chat.meta && j.chat.meta.bot_id;
          if (b) { zaiWsId = b; zaiDiag.wake.push('bot_id=' + b); } } }
      catch (e) { zaiDiag.wake.push('chat-meta:' + e.message); }
      try { const r = await fetch(ZAI_WS + '/user-fc', { headers: H }); zaiDiag.wake.push('user-fc:' + r.status); } catch (e) {}
      for (const p of ['package.json', 'index.html', 'README.md']) {
        try { await fetch(ZAI_WS + '/files/content', { method: 'POST', headers: H, body: JSON.stringify({ chatId: zaiId, rev: 'HEAD', filepath: p, workspace_id: zaiWsId || undefined }) }); zaiDiag.wake.push('wake:' + p); } catch (e) {}
      }
    }
  }
  async function zaiFetchWsId() {
    if (zaiWsId || zaiMode !== 'chat') return;
    const H = { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + zaiToken() };
    const grab = j => { let found = null; (function w(n) { if (found || !n || typeof n !== 'object') return;
      if (Array.isArray(n)) { n.forEach(w); return; }
      for (const k of Object.keys(n)) { if (/^(bot_id|workspace_id)$/i.test(k) && typeof n[k] === 'string' && n[k]) { found = n[k]; return; } w(n[k]); } })(j); return found; };
    for (const u of [location.origin + '/api/v1/chats/' + zaiId, ZAI_WS.replace(/\/workspaces$/, '') + '/deployments?chatId=' + zaiId]) {
      try { const r = await fetch(u, { headers: H }); if (r.ok) { const j = await r.json(); scanQuota(j); const f = grab(j); if (f) { zaiWsId = f; zaiDiag.wake.push('wsId:' + f); return; } } } catch (e) {}
    }
  }
  async function zaiList() {
    if (!zaiMode) return [];
    const share = zaiMode === 'share';
    const url = ZAI_WS + (share ? '/share/files/ls-tree' : '/files/ls-tree');
    const body = share ? { share_id: zaiId } : { chatId: zaiId };
    if (!share && zaiWsId) body.workspace_id = zaiWsId;
    zaiDiag.token = !!zaiToken();
    try {
      const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + zaiToken() }, body: JSON.stringify(body) });
      const txt = await r.text();
      zaiDiag.lsStatus = r.status; zaiDiag.lsBody = txt.slice(0, 200);
      if (!r.ok) { if (r.status === 403) log('Z.ai ls-tree 403 — нет токена, войдите в аккаунт.'); return []; }
      let j; try { j = JSON.parse(txt); } catch (e) { log('Z.ai ls-tree: не JSON: ' + zaiDiag.lsBody.slice(0, 80)); return []; }
      scanQuota(j);
      const out = new Set();
      const isPathStr = v => typeof v === 'string' && v && !TELEM.test(v) && (v.includes('/') || /\.[A-Za-z0-9]{1,10}$/.test(v));
      (function walk(n, prefix) {
        if (Array.isArray(n)) { for (const x of n) { if (isPathStr(x)) { const rel = normPath(x); if (rel && !rel.endsWith('/') && FILE_EXT.test(rel)) out.add(rel); } else walk(x, prefix); } return; }
        if (!n || typeof n !== 'object') return;
        /* узел дерева: {name/path, size?, children?} */
        const nk = Object.keys(n).find(k => /^(name|path|filepath|file_name)$/i.test(k) && typeof n[k] === 'string');
        let myPath = prefix;
        if (nk) {
          const nm = String(n[nk]);
          myPath = normPath(nm.includes('/') ? nm : (prefix ? prefix + '/' + nm : nm));
          const sk = Object.keys(n).find(k => SIZE_KEY(k));
          const isDir = !FILE_EXT.test(myPath) || (n.children || n.files || n.entries || (typeof n.is_dir === 'boolean' && n.is_dir) || (typeof n.type === 'string' && /dir|folder/i.test(n.type)));
          if (!isDir && myPath) out.add(myPath);
          if (sk && okSize(n[sk]) && myPath && FILE_EXT.test(myPath)) setSize(myPath, n[sk]);
        }
        for (const k of Object.keys(n)) { const v = n[k]; if (v && typeof v === 'object') walk(v, /^(children|files|entries|nodes|items)$/i.test(k) ? myPath : prefix); }
      })(j, '');
      if (!out.size) { /* запасной плоский разбор */
        (function walk2(n) {
          if (Array.isArray(n)) { for (const x of n) { if (isPathStr(x)) { const rel = normPath(x); if (rel && FILE_EXT.test(rel)) out.add(rel); } else walk2(x); } return; }
          if (!n || typeof n !== 'object') return;
          for (const k of Object.keys(n)) { const v = n[k];
            if (typeof v === 'string' && /^(path|filepath|name|file_name)$/i.test(k) && isPathStr(v)) { const rel = normPath(v); if (rel && FILE_EXT.test(rel)) out.add(rel); }
            else walk2(v); }
        })(j);
      }
      scanJsonForSizes(j);
      zaiDiag.parsed = out.size;
      if (r.status === 200 && out.size === 0) log('Z.ai ls-tree 200, но распознано 0 путей. Тело: ' + zaiDiag.lsBody.slice(0, 120));
      return [...out];
    } catch (e) { log('Z.ai ls-tree ошибка: ' + e.message); return []; }
  }
  async function zaiContent(p, signal, sizeOnly) {
    const share = zaiMode === 'share';
    const url = ZAI_WS + (share ? '/share/files/content' : '/files/content');
    const body = share ? { share_id: zaiId, rev: 'HEAD', filepath: p } : { chatId: zaiId, rev: 'HEAD', filepath: p };
    if (!share && zaiWsId) body.workspace_id = zaiWsId;
    try {
      const r = await fetch(url, { method: 'POST', signal, headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + zaiToken() }, body: JSON.stringify(body) });
      if (!r.ok) return null;
      const ct = r.headers.get('content-type') || '';
      if (sizeOnly) {
        /* Размер у z.ai: их API отдаёт СОДЕРЖИМОЕ, а не метаданные, поэтому:
           1) есть content-length — берём его;
           2) заголовка нет (обычный поток) — считаем байты, читая тело (до 16 МБ);
           3) пришёл JSON — ищем явное поле размера, иначе считаем текст
              (base64 раскодируем в настоящий размер). */
        const note = (why) => { PROBE_WHY[why] = (PROBE_WHY[why] || 0) + 1; return null; };
        if (!ct.includes('json')) {
          const cl = r.headers.get('content-length');
          if (cl && +cl > 0) {
            try { if (r.body) await r.body.cancel(); } catch (e) {}
            return +cl;
          }
          if (!r.body) return note('пустой ответ');
          if (PROBE_BUDGET <= 0) { try { if (r.body) await r.body.cancel(); } catch (e) {} return note('исчерпан лимит подсчёта (32 МБ за круг)'); }
          const rd = r.body.getReader();
          let total = 0;
          try {
            for (;;) {
              const chunk = await rd.read();
              if (chunk.done) break;
              const n = chunk.value ? chunk.value.length : 0;
              total += n;
              PROBE_BUDGET -= n;
              if (total > 16 * 1024 * 1024) {
                try { await rd.cancel(); } catch (e) {}
                return note('файл больше 16 МБ');
              }
              if (PROBE_BUDGET <= 0) {
                try { await rd.cancel(); } catch (e) {}
                return note('исчерпан лимит подсчёта (32 МБ за круг)');
              }
            }
          } catch (e) { return note('поток прервался'); }
          return total > 0 ? total : note('пустой ответ');
        }
        let j = null;
        try { j = await r.json(); } catch (e) { return note('JSON не разобрался'); }
        let num = null;
        (function walk(n, d) {
          if (num != null || !n || typeof n !== 'object' || d > 4) return;
          if (Array.isArray(n)) { n.forEach(x => walk(x, d + 1)); return; }
          for (const k of Object.keys(n)) {
            if (/^(size|bytes|file_size|filesize|content_length|contentlength|length)$/i.test(k) && typeof n[k] === 'number' && n[k] >= 0) { num = n[k]; return; }
            walk(n[k], d + 1);
          }
        })(j, 0);
        if (num != null) return num;
        const c = (j && (j.content !== undefined ? j.content : (j.data && j.data.content !== undefined ? j.data.content : j.data)));
        if (typeof c !== 'string') return note('в ответе нет содержимого');
        const s = c.trim();
        if (s.length > 3 && s.length % 4 === 0 && /^[A-Za-z0-9+/=\r\n]+$/.test(s)) {
          const pad = (s.endsWith('==') ? 2 : s.endsWith('=') ? 1 : 0);
          return Math.floor(s.length * 3 / 4) - pad;
        }
        return new TextEncoder().encode(c).length;
      }
      if (ct.includes('json')) { const j = await r.json(); const c = (j && (j.content !== undefined ? j.content : (j.data && j.data.content !== undefined ? j.data.content : j.data))); return typeof c === 'string' ? new TextEncoder().encode(c) : null; }
      return new Uint8Array(await r.arrayBuffer());
    } catch (e) { return null; }
  }
  async function zaiArchive() {
    if (!zaiMode) return null;
    const share = zaiMode === 'share';
    try {
      const r = await fetch(ZAI_WS + (share ? '/share/files/archive' : '/files/archive'), { method: 'POST', signal: runAC && runAC.signal, headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + zaiToken() }, body: JSON.stringify(share ? { share_id: zaiId, rev: 'HEAD' } : { chatId: zaiId, rev: 'HEAD' }) });
      if (!r.ok) return null;
      return await r.blob();
    } catch (e) { return null; }
  }

  /* --------------------------------- ZIP ----------------------------------- */
  /*--ZIPSYS-START--*/
  /*--ZIP-START--*/
  const CRC_T = (() => { const t = new Uint32Array(256);
    for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1); t[n] = c >>> 0; }
    return t; })();
  const crc32 = u => { let c = 0xFFFFFFFF; for (let i = 0; i < u.length; i++) c = CRC_T[(c ^ u[i]) & 0xFF] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
  function zipLayout(entries, dt, dd) {
    const enc = new TextEncoder(), chunks = [], central = []; let off = 0;
    for (const e of entries) {
      const u8 = e.u8, nb = enc.encode(e.name), crc = crc32(u8);
      const lh = new DataView(new ArrayBuffer(30));
      lh.setUint32(0, 0x04034b50, true); lh.setUint16(4, 20, true); lh.setUint16(6, 0x0800, true);
      lh.setUint16(10, dt, true); lh.setUint16(12, dd, true);
      lh.setUint32(14, crc, true); lh.setUint32(18, u8.length, true); lh.setUint32(22, u8.length, true);
      lh.setUint16(26, nb.length, true);
      chunks.push(new Uint8Array(lh.buffer), nb, u8);
      const ch = new DataView(new ArrayBuffer(46));
      ch.setUint32(0, 0x02014b50, true); ch.setUint16(4, 20, true); ch.setUint16(6, 20, true); ch.setUint16(8, 0x0800, true);
      ch.setUint16(12, dt, true); ch.setUint16(14, dd, true);
      ch.setUint32(16, crc, true); ch.setUint32(20, u8.length, true); ch.setUint32(24, u8.length, true);
      ch.setUint16(28, nb.length, true); ch.setUint32(42, off, true);
      central.push(new Uint8Array(ch.buffer), nb);
      off += 30 + nb.length + u8.length;
    }
    const cds = central.reduce((s, c) => s + c.length, 0);
    const eo = new DataView(new ArrayBuffer(22));
    eo.setUint32(0, 0x06054b50, true); eo.setUint16(8, entries.length, true);
    eo.setUint16(10, entries.length, true); eo.setUint32(12, cds, true); eo.setUint32(16, off, true);
    return new Blob([...chunks, ...central, new Uint8Array(eo.buffer)], { type: 'application/zip' });
  }
  const zipStamp = () => {
    const d = new Date();
    return { dt: ((d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1)) & 0xFFFF,
             dd: (((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate()) & 0xFFFF };
  };
  const makeZipSync = entries => { const s = zipStamp(); return zipLayout(entries, s.dt, s.dd); };
  /*--ZIP-END--*/

  /* сборка ZIP в Web Worker — главный поток страницы не блокируется (п.1) */
  const WORKER_SRC = [
    'const T=(()=>{const t=new Uint32Array(256);for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=(c&1)?(0xEDB88320^(c>>>1)):(c>>>1);t[n]=c>>>0;}return t;})();',
    'const crc=u=>{let c=0xFFFFFFFF;for(let i=0;i<u.length;i++)c=T[(c^u[i])&0xFF]^(c>>>8);return (c^0xFFFFFFFF)>>>0;};',
    'onmessage=ev=>{const{entries,dt,dd}=ev.data;try{',
    'const enc=new TextEncoder(),chunks=[],central=[];let off=0;',
    'for(const e of entries){const u8=new Uint8Array(e.buf),nb=enc.encode(e.name),c=crc(u8);',
    'const lh=new DataView(new ArrayBuffer(30));',
    'lh.setUint32(0,0x04034b50,true);lh.setUint16(4,20,true);lh.setUint16(6,0x0800,true);',
    'lh.setUint16(10,dt,true);lh.setUint16(12,dd,true);',
    'lh.setUint32(14,c,true);lh.setUint32(18,u8.length,true);lh.setUint32(22,u8.length,true);',
    'lh.setUint16(26,nb.length,true);',
    'chunks.push(new Uint8Array(lh.buffer),nb,u8);',
    'const ch=new DataView(new ArrayBuffer(46));',
    'ch.setUint32(0,0x02014b50,true);ch.setUint16(4,20,true);ch.setUint16(6,20,true);ch.setUint16(8,0x0800,true);',
    'ch.setUint16(12,dt,true);ch.setUint16(14,dd,true);',
    'ch.setUint32(16,c,true);ch.setUint32(20,u8.length,true);ch.setUint32(24,u8.length,true);',
    'ch.setUint16(28,nb.length,true);ch.setUint32(42,off,true);',
    'central.push(new Uint8Array(ch.buffer),nb);',
    'off+=30+nb.length+u8.length;}',
    'const cds=central.reduce((s,x)=>s+x.length,0);',
    'const eo=new DataView(new ArrayBuffer(22));',
    'eo.setUint32(0,0x06054b50,true);eo.setUint16(8,entries.length,true);eo.setUint16(10,entries.length,true);',
    'eo.setUint32(12,cds,true);eo.setUint32(16,off,true);',
    'const blob=new Blob(chunks.concat(central,[new Uint8Array(eo.buffer)]),{type:"application/zip"});',
    'postMessage({ok:true,blob});}catch(err){postMessage({ok:false,err:String(err)});}};'
  ].join('\n');
  let zipWorker = null, zipWorkerBroken = false;
  const ZIP_COPY_LIMIT = 16 * 1024 * 1024;   // до этого размера партию дешевле скопировать
  const ZIP_TIMEOUT = 120000;  /* Восстановление партии после падения воркера: имя записи в архиве — это путь
     файла в рабочей области, поэтому байты можно запросить заново. */
  async function refetchEntries(entries) {
    const out = [];
    for (const e of entries) {
      if (STOP) break;
      let b = null;
      try { b = await fetchBytes(e.name, runAC && runAC.signal); } catch (err) { b = null; }
      if (b instanceof Uint8Array && b.length) out.push({ name: e.name, u8: b });
      else log('  ↳ не удалось перезапросить файл: ' + e.name);
    }
    return out;
  }
  function getZipWorker() {
    if (zipWorker || zipWorkerBroken) return zipWorker;
    try {
      const u = URL.createObjectURL(new Blob([WORKER_SRC], { type: 'text/javascript' }));
      zipWorker = new Worker(u);
      URL.revokeObjectURL(u);
      zipWorker.onerror = () => { try { zipWorker.terminate(); } catch (e) {} zipWorker = null; zipWorkerBroken = true; };
    } catch (e) { zipWorker = null; zipWorkerBroken = true; }
    return zipWorker;
  }
  /* Крупные партии отдаём в воркер БЕЗ КОПИИ (transfer): на архиве в сотни
     мегабайт копия удваивала память. Если воркер всё-таки упал, исходных байт в
     главном потоке уже нет — тогда перезапрашиваем их и собираем архив здесь,
     чтобы вместо архива не записался битый файл. Мелкие партии копируем: копия
     дёшева, а откат работает на исходных байтах. */
  function makeZipAsync(entries) {
    const total = entries.reduce((s, e) => s + e.u8.length, 0);
    const canTransfer = total >= ZIP_COPY_LIMIT && entries.every(e => {
      const b = e.u8.buffer;
      return b && e.u8.byteOffset === 0 && e.u8.byteLength === b.byteLength;
    });
    return new Promise(resolve => {
      const w = getZipWorker();
      if (!w) { resolve(makeZipSync(entries)); return; }
      const s = zipStamp();
      const msg = entries.map(e => ({ name: e.name, buf: e.u8.buffer }));
      const list = canTransfer ? entries.map(e => e.u8.buffer) : null;
      let settled = false;
      function done(blob) { if (settled) return; settled = true; clearTimeout(to); resolve(blob); }
      async function fallback() {
        if (settled) return;
        settled = true;
        clearTimeout(to);
        try { w.terminate(); } catch (e) {}
        zipWorker = null; zipWorkerBroken = true;
        if (!list) { resolve(makeZipSync(entries)); return; }
        const again = await refetchEntries(entries);      // буферы уже ушли в воркер
        if (!again.length) { log('Сборка ZIP сорвалась: воркер недоступен, а перезапросить файлы не удалось.'); resolve(null); return; }
        if (again.length < entries.length) log('  в архив не попало файлов: ' + (entries.length - again.length) + ' (не удалось перезапросить)');
        resolve(makeZipSync(again));
      }
      const to = setTimeout(fallback, ZIP_TIMEOUT);
      w.onerror = fallback;
      w.onmessage = ev => { if (ev.data && ev.data.ok) done(ev.data.blob); else fallback(); };
      try { w.postMessage({ entries: msg, dt: s.dt, dd: s.dd }, list || []); } catch (e) { fallback(); }
    });
  }

  /*--ZIPSYS-END--*/

  /* ------------------------------- мост расширения -------------------------- */
  let HAS_BRIDGE = false, hintedCORS = false;
  addEventListener('wzr:hello', () => { HAS_BRIDGE = true; });
  const b64ToU8 = b => { const bin = atob(b); const u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u; };
  function bridgeCall(type, payload, ms) {
    return new Promise(resolve => {
      if (!HAS_BRIDGE) return resolve(null);
      const id = type + Math.random().toString(36).slice(2);
      const resEv = type === 'wzr-fetch' ? 'wzr:fetchres' : 'wzr:sizeres';
      const reqEv = type === 'wzr-fetch' ? 'wzr:fetchreq' : 'wzr:sizereq';
      const to = setTimeout(() => { cleanup(); resolve(null); }, ms || 180000);
      function onRes(ev) { if (!ev.detail || ev.detail.id !== id) return; cleanup(); resolve(ev.detail); }
      function cleanup() { clearTimeout(to); removeEventListener(resEv, onRes); }
      addEventListener(resEv, onRes);
      window.dispatchEvent(new CustomEvent(reqEv, { detail: Object.assign({ id }, payload) }));
    });
  }
  /* Обход CORS через фон: мелкий файл — одним сообщением, крупный — кусками по
     Range (фон отдаёт не больше 48 МБ за раз). Так снимается прежнее
     ограничение «крупный файл с чужого CDN не скачать». */
  const EXT_CHUNK = 24 * 1024 * 1024;
  async function extFetch(url, signal) {
    const one = await bridgeCall('wzr-fetch', { url }, 180000);
    if (one && one.ok && typeof one.b64 === 'string') return b64ToU8(one.b64);
    if (!one || (signal && signal.aborted)) return null;
    const total = one.total || one.size || 0;
    if (!total || total <= 0) return null;
    const out = new Uint8Array(total);
    const steps = Math.ceil(total / EXT_CHUNK) + 4;
    let got = 0, guard = 0;
    while (got < total && guard++ < steps) {
      if (signal && signal.aborted) return null;
      const end = Math.min(got + EXT_CHUNK - 1, total - 1);
      const part = await bridgeCall('wzr-fetch', { url, range: 'bytes=' + got + '-' + end }, 180000);
      if (!part || !part.ok || typeof part.b64 !== 'string') {
        if (part && part.rangeIgnored) log('Крупный файл: сервер не отдаёт его частями — обходной путь недоступен.');
        return null;
      }
      const u8 = b64ToU8(part.b64);
      if (!u8.length || got + u8.length > total) return null;
      out.set(u8, got);
      got += u8.length;
    }
    return got === total ? out : null;
  }
  async function extSize(url) {
    const r = await bridgeCall('wzr-size', { url }, 15000);
    return r && r.ok && typeof r.size === 'number' ? r.size : null;
  }

  /* ------------------------------- скачивание ------------------------------ */
  async function fetchBytes(p, signal) {
    const u = urlFor(p);
    if (!u) return null;
    if (u.startsWith('zai:')) return await zaiContent(p, signal);
    if (u.startsWith('blob:') && blobs.has(u)) { const b = blobs.get(u); return new Uint8Array(await b.arrayBuffer()); }
    let first = null;
    try {
      const r = await fetch(u, { credentials: 'include', signal });
      if (r.ok) return new Uint8Array(await r.arrayBuffer());
      first = { http: r.status };
    } catch (e) { if (signal && signal.aborted) return { err: 'abort' }; first = { err: e.message }; }
    const fb = fallbackUrl(p);
    if (fb) {
      try {
        const r2 = await fetch(fb, { credentials: 'include', signal });
        if (r2.ok) { log('  ↳ ' + p.split('/').pop() + ': взял ссылку из трафика страницы'); return new Uint8Array(await r2.arrayBuffer()); }
      } catch (e) { if (signal && signal.aborted) return { err: 'abort' }; }
      const ex = await extFetch(fb, signal);
      if (ex) { log('  ↳ ' + p.split('/').pop() + ': получено через расширение (обход CORS)'); return ex; }
      if (!HAS_BRIDGE && !hintedCORS) { hintedCORS = true; log('CDN отдаёт файл без CORS: браузер не даст байты странице. Запустите расширение (клик по иконке) — оно доберёт само.'); }
    }
    return first;
  }
  function fallbackUrl(p) {
    const seg = p.split('/');
    const t3 = '/' + seg.slice(-3).join('/');
    const t2 = '/' + seg.slice(-2).join('/');
    for (let i = extraUrls.length - 1; i >= 0; i--) {
      const u = extraUrls[i].u;
      if (u.includes(t3) || u.includes(t2)) return u;
    }
    return null;
  }
  const MIME = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', svg: 'image/svg+xml', webp: 'image/webp', ico: 'image/x-icon',
    mp3: 'audio/mpeg', wav: 'audio/wav', ogg: 'audio/ogg', mp4: 'video/mp4', webm: 'video/webm',
    json: 'application/json', pdf: 'application/pdf', zip: 'application/zip',
    html: 'text/html', htm: 'text/html', css: 'text/css', js: 'text/javascript', ts: 'text/plain', tsx: 'text/plain', jsx: 'text/plain',
    md: 'text/markdown', txt: 'text/plain', xml: 'text/xml', srt: 'text/plain', vtt: 'text/plain', ass: 'text/plain', py: 'text/plain' };
  const mimeFor = n => {
    const m = MIME[(n.split('.').pop() || '').toLowerCase()] || 'application/octet-stream';
    return (/^text\//.test(m) || m === 'application/json' || m === 'image/svg+xml') ? m + ';charset=utf-8' : m;
  };

  async function saveOne(p, signal) {           // скачать один файл «как есть»
    const b = await fetchBytes(p, signal);
    if (!(b instanceof Uint8Array) || (signal && signal.aborted)) return false;
    const name = p.split('/').pop();
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([b], { type: mimeFor(name) }));
    a.download = name;
    document.body.appendChild(a); a.click();
    setTimeout(u => { URL.revokeObjectURL(u); }, 5 * 60 * 1000, a.href);
    a.remove();
    return true;
  }

  /* ------------------------------- ПАНЕЛЬ (V1) ------------------------------ */
  const P = document.createElement('div');
  P.id = 'wzrPanel';
  P.style.cssText = 'position:fixed;top:12px;right:12px;z-index:2147483647;width:440px;height:calc(100vh - 24px);max-height:calc(100vh - 24px);background:#151521;' +
    'color:#eee;font:14.5px/1.45 monospace;border-radius:10px;border:1px solid #3a3a55;box-shadow:0 8px 28px rgba(0,0,0,.6);' +
    'user-select:none;display:flex;flex-direction:column;overflow:hidden';
  const PIN_SVG = '<svg viewBox="0 0 24 24" width="14" height="14"><path d="M14 4v5c0 1.12.37 2.16 1 3H9c.65-.86 1-1.9 1-3V4h4m4-2H6c-.55 0-1 .45-1 1s.45 1 1 1h1v5c0 1.66-1.34 3-3 3v2h5.97v7l1 1 1-1v-7H19v-2c-1.66 0-3-1.34-3-3V4h1c.55 0 1-.45 1-1s-.45-1-1-1z"/></svg>';
  P.innerHTML =
    '<div id="grip" title="Потяните, чтобы изменить ширину панели"></div>' +
    '<div id="hd" style="cursor:move;padding:8px 10px;background:#1d2b1d;border-radius:10px 10px 0 0;display:flex;gap:6px;align-items:center">' +
    '<b style="color:#7fd67f;flex:1" title="WORKSPACE V1 · сборка ' + WZR_BUILD + '">WORKSPACE V1 · ' + (IS_QWEN ? 'QWEN' : IS_ZAI ? 'Z.AI' : HOST.replace(/^www\./, '')) + '</b>' +
    '<button id="pin" title="Закрепить как боковую панель (страница сдвинется) / открепить">' + PIN_SVG + '</button>' +
    '<button data-a="left" title="К левому краю">◀</button><button data-a="right" title="К правому краю">▶</button>' +
    '<button data-a="min" title="Свернуть / развернуть">—</button><button data-a="close" class="wzrX" title="Закрыть панель">×</button></div>' +
    '<div class="wzrTabs">' +
    '<button id="tabMain" class="wzrTab">ГЛАВНАЯ</button>' +
    '<button id="tabSet" class="wzrTab">НАСТРОЙКИ</button>' +
    '</div>' +
    /* ---------- главная: дерево скроллится внутри, кнопки зафиксированы внизу ---------- */
    '<div id="bodyMain" style="padding:8px 10px 10px;display:flex;flex-direction:column;flex:1;min-height:0;overflow:hidden">' +
    '<div id="mem" style="flex:0 1 auto;min-height:0;overflow:hidden" title="Память рабочей области"><div id="memTxt">память: …</div><div id="memBar"><div id="memFill"></div></div></div>' +
    '<div id="c" style="flex:0 1 auto;min-height:0;overflow:hidden">Нажмите ОБНОВИТЬ…</div>' +
    '<div style="margin-top:6px;display:flex;gap:5px;align-items:center;flex:0 0 auto">' +
    '<button id="sortBtn" title="Сортировка дерева: А-Я → по размеру → в порядке сервера">СОРТ: А-Я</button>' +
    '<input id="fl" style="flex:1;min-width:40px" placeholder="фильтр по пути">' +
    '<button id="all" class="wzrIconBtn" title="Отметить всё / снять всё">&#9745;</button></div>' +
    '<div id="tree" style="margin-top:8px;flex:1 1 0;min-height:0;max-height:none;overflow:auto;background:#0d0d16;border:1px solid #2c2c40;border-radius:4px;padding:6px"></div>' +
    '<div id="stat" style="margin-top:6px;color:#9ad;flex:0 0 auto"></div>' +
    '<div id="log" class="wzrLog"></div>' +
    /* нижняя панель: строка прогресса (сверху) и кнопки (всегда у нижнего края) */
    '<div id="foot">' +
    '<div id="prog"><div id="progTxt"></div><div id="progBar"><div id="progFill"></div></div></div>' +
    '<button id="go" class="wzrGo" title="Скачать отмеченное одним ZIP">СКАЧАТЬ ZIP</button><button id="goRaw" class="wzrGo" title="Скачать отмеченное отдельными файлами">СКАЧАТЬ КАК ЕСТЬ</button>' +
    '<button id="refresh" title="Перечитать список файлов">ОБНОВИТЬ</button><button id="arch" class="' + (IS_ZAI ? '' : 'wzrHide') + '">АРХИВ ВСЕЙ ОБЛАСТИ</button><button id="catch" class="' + ((IS_ZAI || IS_QWEN) ? 'wzrHide' : '') + '">ПОЙМАТЬ ССЫЛКУ</button>' +
    '<button id="stop" class="wzrX" style="display:none" title="Мгновенно отменить скачивание">СТОП</button></div>' +
    '</div>' +
    /* ---------------- настройки ---------------- */
    '<div id="bodySet" style="display:none;padding:8px 10px 10px;overflow:auto;flex:1 1 auto;min-height:0">' +
    '<div class="wzrSec"><b>Сайты</b><div style="margin-top:5px;display:flex;gap:5px;flex-wrap:wrap">' +
    '<button id="openQ">Открыть chat.qwen.ai ↗</button><button id="openZ">Открыть chat.z.ai ↗</button></div></div>' +
    '<div class="wzrSec"><b>Размеры и память</b><div style="margin-top:5px">' +
    '<div style="margin-bottom:4px">Размеры файлов и память:</div>' +
    '<select id="szMode" style="width:100%">' +
    '<option value="full">Отображать размеры файлов</option>' +
    '<option value="off">Не отображать размеры (выключено)</option>' +
    '</select>' +
    '<div style="color:#9aa3b5;margin-top:5px;font-size:13.5px;line-height:1.45">' +
    '<b>Отображать размеры файлов</b> — запрашивает размер каждого файла: суммы по папкам, шкала памяти и объём в статистике.<br>' +
    '<b>Не отображать</b> — запросов к сайту нет; колонка размеров и шкала памяти скрыты, в статистике только количество файлов.' +
    '</div>' +
    '<div style="margin-top:5px">Общий объём области, ГБ (0 = определить автоматически из API): <input id="quotaGB" type="number" min="0" step="1" style="width:64px"></div>' +
    '<div style="margin-top:6px"><button id="szNow" title="Разово запросить размеры всех файлов (HEAD/Range)">УЗНАТЬ РАЗМЕРЫ СЕЙЧАС</button></div></div></div>' +
    '<div class="wzrSec"><b>Масштаб и шрифт</b><div style="margin-top:5px">' +
    '<select id="fsMode" style="width:100%">' +
    '<option value="big">Крупный</option>' +
    '<option value="medium">Средний</option>' +
    '<option value="small">Мелкий</option>' +
    '</select>' +
    '<div style="color:#9aa3b5;margin-top:5px;font-size:13.5px;line-height:1.45">Размер текста в панели. Запоминается для каждого сайта отдельно.</div>' +
    '<div id="fsSample" style="margin-top:6px;padding-top:6px;border-top:1px dashed #2c2c40;color:#cfd6e4">Пример: папка/файл_2026.pdf — 1,2 МБ</div>' +
    '</div></div>' +
    '<div class="wzrSec"><b>Диагностика</b>' +
    '<div style="color:#9aa3b5;margin-top:4px;font-size:13.5px">Если дорабатываете программу с агентом — сделайте диагностику, скопируйте отчёт и отправьте ему.</div>' +
    '<div style="margin-top:6px;display:flex;gap:5px;flex-wrap:wrap">' +
    '<button id="runDiag" class="wzrGo">СДЕЛАТЬ ДИАГНОСТИКУ</button><button id="copylog">КОПИРОВАТЬ ЛОГ</button></div></div>' +
    '<div class="wzrSec"><b>О программе</b><div style="color:#cfd6e4;margin-top:3px">Workspace Rescue V1 — забирает файлы из рабочей области чатов <b>chat.z.ai</b> и <b>chat.qwen.ai</b>.</div>' +
    '<ul class="wzrAbout">' +
    '<li>В режиме агента сайты создают файлы в вашей рабочей области, но отдать их не всегда могут: chat.z.ai часто не даёт скачать готовое, у chat.qwen.ai бывает, что чат вообще не отвечает.</li>' +
    '<li>Проект лежит папками, и тянуть каждый файл по одному долго. Здесь всё скачивается <b>одним архивом</b> с сохранением структуры папок.</li>' +
    '<li>Бывает, что файл уже создан, а сайт кнопку скачивания так и не показал — в панели он всё равно виден, и его можно забрать.</li>' +
    '<li>Всё работает в вашем браузере: ничего не отправляется на сторонние серверы.</li>' +
    '</ul></div>' +
    '<div class="wzrSec" style="color:#7a8499">Workspace Rescue V1 · только для личного использования на ваших чатах.</div>' +
    '<div style="color:#5f6a80;font-size:12.5px;text-align:right;padding:2px 4px 0">Автор: <span style="color:#b98cff">Рэйф_72</span></div>' +
    '</div>';
  document.body.appendChild(P);
  const $ = s => P.querySelector(s);
  const L = [];
  /* Журнал: каждая строка — свой элемент, поэтому ошибки видны красным,
     новые файлы — жёлтым, а успешные сохранения — зелёным. */
  const LOG_KIND = { err: 'wzrErr', new: 'wzrNew', ok: 'wzrOk' };
  function log(t, kind) {
    if (SILENT) return;
    L.push(t);
    if (L.length > 400) L.shift();
    const el = $('#log');
    if (!el) return;
    const line = document.createElement('div');
    if (LOG_KIND[kind]) line.className = LOG_KIND[kind];
    line.textContent = t;
    el.appendChild(line);
    while (el.childNodes.length > 400) el.removeChild(el.firstChild);
    el.scrollTop = el.scrollHeight;
  }
  async function copyText(t, msg) {
    try { await navigator.clipboard.writeText(t); log(msg); }
    catch (e) {
      const ta = document.createElement('textarea');
      ta.value = t; ta.style.cssText = 'position:fixed;top:0;left:0;opacity:.01';
      document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); log(msg); } catch (e2) { log(msg + ' — не удалось скопировать'); }
      ta.remove();
    }
  }
  /* ------------------------------ прогресс-бар ----------------------------- */
  function progShow(txt, pct, ind) {
    $('#prog').style.display = 'block';
    $('#progTxt').textContent = txt;
    const f = $('#progFill');
    f.classList.toggle('ind', !!ind);
    if (!ind) f.style.width = Math.max(0, Math.min(100, pct || 0)) + '%';
  }
  function progHide() { $('#prog').style.display = 'none'; $('#progFill').classList.remove('ind'); }
  function progDone(txt) { progShow(txt, 100); setTimeout(progHide, 6000); }

  /* ------------------------- вкладки / скрепка / шапка ---------------------- */
  function setTab(t) {
    UI.tab = t; saveUI();
    $('#tabMain').classList.toggle('wzrTabOn', t === 'main');
    if (DEAD) return;
    applyFontMode();
    $('#tabSet').classList.toggle('wzrTabOn', t === 'set');
    const bm = $('#bodyMain'), bs = $('#bodySet');
    bm.classList.toggle('wzrHidden', t !== 'main');
    bs.classList.toggle('wzrHidden', t !== 'set');
    bm.style.display = t === 'main' ? 'flex' : 'none';
    bs.style.display = t === 'set' ? '' : 'none';
    $('#hd').style.borderRadius = UI.dock ? '0' : '10px 10px 0 0';
    fitLater();                     // у вкладок разная высота — пересчитываем
  }
  $('#tabMain').onclick = () => setTab('main');
  $('#tabSet').onclick = () => setTab('set');

  function panelVisible() { return P.style.display !== 'none'; }
  function setPageMargin(px) {
    try {
      const de = document.documentElement;
      de.style.transition = 'margin .12s ease';
      if (px && UI.dock === 'right') { de.style.marginRight = Math.round(px) + 'px'; de.style.marginLeft = ''; }
      else if (px && UI.dock === 'left') { de.style.marginLeft = Math.round(px) + 'px'; de.style.marginRight = ''; }
      else { de.style.marginLeft = ''; de.style.marginRight = ''; }
    } catch (e) {}
  }
  function dockWidth() {
    const def = Math.round(Math.max(340, innerWidth * 0.34));
    return Math.max(320, UI.w || def);
  }
  /* высота панели: закреплённая — во всю высоту окна, плавающая — тоже
     растягивается на всё окно (минус поля), иначе дерево файлов не сможет
     дойти до нижней панели с кнопками. */
  function panelMaxH() { return Math.max(260, Math.round(innerHeight * 0.92)); }
  /* по умолчанию — компактная панель (480px или меньше, если окно низкое) */
  function floatH() {
    const def = Math.min(panelMaxH(), Math.round(innerHeight * 0.86), 700);
    return UI.h ? Math.max(300, Math.min(UI.h, panelMaxH())) : def;
  }
  function applyDock() {
    if (DEAD) return;
    if (P.style.display !== 'none') P.style.display = 'flex';   // страховка: без flex раскладка рассыпается
    const g = $('#grip');
    if (UI.dock) {
      P.classList.add('docked');
      P.style.top = '0'; P.style.bottom = '0'; P.style.height = '100vh'; P.style.maxHeight = '100vh';
      P.style.left = UI.dock === 'left' ? '0' : 'auto';
      P.style.right = UI.dock === 'right' ? '0' : 'auto';
      P.style.maxWidth = ''; P.style.width = dockWidth() + 'px';
      P.style.boxShadow = UI.dock === 'right' ? '-14px 0 36px rgba(0,0,0,.55)' : '14px 0 36px rgba(0,0,0,.55)';
      $('#pin').classList.add('wzrPinned');
      $('#pin').title = 'Открепить панель (станет плавающей поверх страницы)';
      if (panelVisible()) setPageMargin(P.getBoundingClientRect().width || dockWidth());
    } else {
      P.classList.remove('docked');
      P.style.bottom = 'auto'; P.style.maxWidth = ''; P.style.width = (UI.w || 440) + 'px'; P.style.top = '12px';
      P.style.height = floatH() + 'px'; P.style.maxHeight = panelMaxH() + 'px';
      P.style.boxShadow = '0 8px 28px rgba(0,0,0,.6)';
      $('#pin').classList.remove('wzrPinned');
      $('#pin').title = 'Закрепить как боковую панель — страница сдвинется; переживёт обновление';
      setPageMargin(0);
    }
    if (g) {
      positionGrip();
    }
    ensureHGrip();
    ensureCorners();
    fitHeight();
    $('#hd').style.borderRadius = UI.dock ? '0' : '10px 10px 0 0';
  }
  function positionGrip() {
    const g = $('#grip');
    if (g) { g.style.left = 'auto'; g.style.right = '-4px'; bindGrip(g, 'right'); }
    let gl = $('#gripL');
    if (!gl) {
      gl = document.createElement('div');
      gl.id = 'gripL';
      gl.title = 'Потяните, чтобы изменить ширину панели';
      P.appendChild(gl);
    }
    bindGrip(gl, 'left');
    /* в закреплённом режиме внешний бок прижат к краю экрана — его ползунок не нужен */
    gl.style.display = UI.dock === 'left' ? 'none' : '';
    if (g) g.style.display = UI.dock === 'right' ? 'none' : '';
  }
  /* углы: тянем — меняются ширина И высота одновременно */
  function bindCorner(el, side) {
    if (!el || el.__wzrBound) return;
    el.__wzrBound = true;
    el.addEventListener('mousedown', e => {
      if (UI.dock) return;
      e.preventDefault(); e.stopPropagation();
      const r = P.getBoundingClientRect();
      const vw = innerWidth, vh = innerHeight;
      startShield(side === 'br' ? 'nwse-resize' : 'nesw-resize');
      const startX = e.clientX, startY = e.clientY, startW = r.width, startH = r.height;
      const leftFixed = r.left, topFixed = r.top;
      /* фиксируем противоположный угол */
      P.style.left = Math.round(r.left) + 'px'; P.style.right = 'auto';
      P.style.top = Math.round(r.top) + 'px'; P.style.bottom = 'auto';
      const maxW = Math.max(320, Math.round(vw * 0.92));
      const maxH = Math.max(260, Math.round(vh * 0.92));
      const move = ev => {
        let w = side === 'br' ? startW + (ev.clientX - startX) : startW - (ev.clientX - startX);
        let h = startH + (ev.clientY - startY);
        w = Math.max(320, Math.min(maxW, Math.round(w)));
        h = Math.max(260, Math.min(maxH, Math.round(h)));
        if (side === 'bl') P.style.left = Math.round(leftFixed + (startW - w)) + 'px';
        P.style.width = w + 'px'; P.style.height = h + 'px';
        P.style.maxWidth = maxW + 'px'; P.style.maxHeight = maxH + 'px';
        UI.w = w; UI.h = h;
      };
      const up = () => {
        document.removeEventListener('mousemove', move);
        document.removeEventListener('mouseup', up);
        stopShield();
        P.style.maxHeight = '92vh';
        saveUI();
        fitHeight();
      };
      document.addEventListener('mousemove', move);
      document.addEventListener('mouseup', up);
    });
  }
  function ensureCorners() {
    for (const [id, side] of [['gripBR', 'br'], ['gripBL', 'bl']]) {
      let el = $('#' + id);
      if (!el) {
        el = document.createElement('div');
        el.id = id; el.className = 'wzrCorner';
        el.title = 'Потяните за угол — ширина и высота сразу';
        P.appendChild(el);
      }
      bindCorner(el, side);
    }
  }

  /* нижняя полоска: тянем — меняем высоту плавающей панели (запоминается) */
  let draggingH = false;
  function ensureHGrip() {
    let gb = $('#gripB');
    if (!gb) {
      gb = document.createElement('div');
      gb.id = 'gripB';
      gb.title = 'Потяните, чтобы изменить высоту панели';
      P.appendChild(gb);
      gb.addEventListener('mousedown', e => {
        if (UI.dock) return;
        e.preventDefault();
        draggingH = true;
        startShield('ns-resize');
        const startY = e.clientY, startH = P.getBoundingClientRect().height;
        const move = ev => {
          const h = Math.max(240, Math.min(panelMaxH(), Math.round(startH + (ev.clientY - startY))));
          P.style.height = h + 'px';
        };
        const up = () => {
          document.removeEventListener('mousemove', move);
          document.removeEventListener('mouseup', up);
          draggingH = false;
          stopShield();
          const h = parseInt(P.style.height, 10);
          if (h > 0) { UI.h = h; saveUI(); }
          P.style.maxHeight = panelMaxH() + 'px';
        };
        document.addEventListener('mousemove', move);
        document.addEventListener('mouseup', up);
      });
    }
    gb.style.display = UI.dock ? 'none' : '';
    return gb;
  }

  /* Высота панели. Всегда конкретная высота — иначе дерево файлов не сможет
     растянуться (в flex-контейнере без определённой высоты оно схлопнется).
     Дерево прокручивается внутри, подвал с кнопками остаётся внизу. */
  let fitT = 0;
  function fitHeight() {
    if (DEAD) return;
    if (P.style.display === 'none') return;
    try { if (typeof getComputedStyle === 'function' && getComputedStyle(P).display !== 'flex') P.style.display = 'flex'; } catch (e) {}   // лечим «осевшую» панель
    /* закреплённая — во всю высоту окна */
    if (UI.dock) {
      P.style.height = '100vh';
      P.style.maxHeight = '100vh';
      P.style.top = '0';
      P.style.bottom = '0';
      return;
    }
    if (P.classList.contains('wzrCollapsed')) { P.style.height = 'auto'; P.style.maxHeight = 'none'; return; }
    const b = $('#bodyMain');
    if (b && b.style.display === 'none') return;          // свёрнута — не трогаем
    if (draggingH) return;                                  // пользователь тянет высоту
    P.style.height = floatH() + 'px';
    P.style.maxHeight = panelMaxH() + 'px';
    P.style.top = '12px';
    P.style.bottom = 'auto';
  }
  /* ПРАВИЛО РАСКЛАДКИ (главное):
     1) нижняя панель с кнопками — всегда внизу и никогда не сжимается;
     2) список файлов получает всё свободное место и прокручивается внутри;
     3) журнал (вывод терминала) занимает остаток и уступает первым, если
        окно низкое. Поэтому поле с файлами не сжимается до «двух миллиметров»,
        а кнопки «СКАЧАТЬ ZIP» не исчезают даже при тысяче файлов. */
  const TREE_MIN = 120, LOG_MAX = 88;
  function layoutMain() {
    const bm = $('#bodyMain'), tree = $('#tree'), log = $('#log'), mem = $('#mem'), c = $('#c');
    if (!bm || !tree || !log || !mem || !c) return;
    if (bm.style.display === 'none') return;                 // вкладка не открыта
    const cs = getComputedStyle(bm);
    const avail = bm.clientHeight - (parseFloat(cs.paddingTop) || 0) - (parseFloat(cs.paddingBottom) || 0);
    if (!(avail > 0)) return;
    /* ручные размеры сбрасываем — считаем раскладку заново от «чистого» состояния */
    mem.style.height = ''; c.style.height = ''; log.style.height = '';
    const withMargins = e => {
      const s = getComputedStyle(e);
      return e.getBoundingClientRect().height + (parseFloat(s.marginTop) || 0) + (parseFloat(s.marginBottom) || 0);
    };
    let hard = 0;                                            // то, что не сжимается (инструменты, статистика, кнопки)
    for (const ch of bm.children) {
      if (ch === tree || ch === log || ch === mem || ch === c) continue;
      const s = getComputedStyle(ch);
      if (s.display === 'none') continue;
      hard += withMargins(ch);
    }
    const memH = withMargins(mem), cH = withMargins(c);
    let logH = Math.max(0, Math.min(LOG_MAX, avail - hard - memH - cH - TREE_MIN));
    const logEff = logH > 0 ? logH : 10;                      // рамка журнала всё равно занимает ~10px
    let aux = memH + cH;                                     // шкала памяти и строка-подсказка
    let deficit = TREE_MIN - (avail - hard - aux - logEff);
    if (deficit > 0) {                                       // места мало — уступает память и подсказка
      const takeMem = Math.min(memH, deficit); deficit -= takeMem;
      const takeC = Math.min(cH, deficit);
      mem.style.height = Math.max(0, memH - takeMem) + 'px';
      mem.style.overflow = 'hidden';
      c.style.height = Math.max(0, cH - takeC) + 'px';
      c.style.overflow = 'hidden';
    }
    log.style.height = logH + 'px';
    log.style.flex = '0 1 ' + logH + 'px';
  }
  function fitLater() { clearTimeout(fitT); fitT = setTimeout(fitHeight, 120); }
  /* Полная выгрузка скрипта из страницы. После неё фон снова считает, что панели
     нет (window.__wzrBuild стёрт), и клик по иконке внедряет свежий content.js —
     без перезагрузки страницы и без остатков старой сборки. */
  function uninstall() {
    DEAD = true;
    try { UI.hidden = true; saveUI(); } catch (e) {}
    try { setPageMargin(0); } catch (e) {}
    try { clearInterval(iTimerCap); } catch (e) {}
    try { clearInterval(iTimerRefresh); } catch (e) {}
    try { clearInterval(iTimerChat); } catch (e) {}
    try { clearTimeout(fitT); } catch (e) {}
    try { clearTimeout(flT); } catch (e) {}
    try { if (P && P.parentNode) P.parentNode.removeChild(P); } catch (e) {}
    try { ST.remove(); } catch (e) {}
    try { const cm = document.getElementById('wzrCM'); if (cm) cm.remove(); } catch (e) {}
    try { stopShield(); } catch (e) {}
    try { if (origFetch) window.fetch = origFetch; } catch (e) {}
    try { delete window.__wzrV1; delete window.__wzrBuild; delete window.__wzrTeardown; } catch (e) {}
    try { console.info('WORKSPACE: панель выгружена — следующий клик по иконке запустит свежую копию'); } catch (e) {}
  }
  try { window.__wzrTeardown = () => uninstall(); } catch (e) {}
  function toggleDock() {
    if (UI.dock) {
      /* ОТКРЕПИТЬ: панель остаётся ТОЧНО там же, где была — просто становится
         плавающей (её можно перетащить за шапку). Никаких прыжков на другую сторону. */
      const r = P.getBoundingClientRect();
      UI.dock = null; UI.w = Math.round(r.width) || 0; saveUI(); applyDock();
      P.style.left = Math.round(r.left) + 'px';
      P.style.right = 'auto';
      P.style.top = Math.max(8, Math.min(Math.round(r.top), innerHeight - 120)) + 'px';
      positionGrip();

    } else {
      const r = P.getBoundingClientRect();
      /* ширину сохраняем — закрепление не должно «прыгать» по размеру */
      UI.w = Math.max(320, Math.round(r.width) || 0) || UI.w;
      UI.dock = (r.left + r.width / 2) < innerWidth / 2 ? 'left' : 'right';
      saveUI(); applyDock();

    }
  }
  $('#pin').onclick = toggleDock;

  /* --- щит на время перетаскивания ---------------------------------------
     Превью файла на сайте — это <iframe>. Когда курсор уходит на него, страница
     перестаёт получать mousemove, и растягивание «замирает» (можно сузить, но не
     расширить). Прозрачный щит поверх всего перехватывает движения. */
  let dragShield = null;
  function startShield(cursor) {
    stopShield();
    dragShield = document.createElement('div');
    dragShield.id = 'wzrShield';
    dragShield.style.cssText = 'position:fixed;left:0;top:0;right:0;bottom:0;z-index:2147483646;' +
      'cursor:' + (cursor || 'default') + ';background:transparent';
    document.body.appendChild(dragShield);
  }
  function stopShield() {
    if (dragShield && dragShield.parentNode) dragShield.parentNode.removeChild(dragShield);
    dragShield = null;
  }

  /* изменение ширины: тянем за ЛЮБОЙ бок — левый или правый */
  let rzOn = false, rzSide = 'right';
  function bindGrip(grip, side) {
    if (!grip || grip.__wzrBound) return;
    grip.__wzrBound = true;
    grip.addEventListener('mousedown', e => {
      rzOn = true; rzSide = side;
      e.preventDefault(); e.stopPropagation();
      startShield('ew-resize');
      const r0 = P.getBoundingClientRect();
      const vw = document.documentElement.clientWidth || innerWidth;
      /* закрепляем противоположный край: двигается именно тот бок, за который взялись */
      if (!UI.dock) {
        if (side === 'left') { P.style.left = 'auto'; P.style.right = Math.max(0, Math.round(vw - r0.right)) + 'px'; }
        else { P.style.right = 'auto'; P.style.left = Math.round(r0.left) + 'px'; }
      }
      try { document.body.style.cursor = 'ew-resize'; document.body.style.userSelect = 'none'; } catch (err) {}
    });
  }
  addEventListener('mousemove', e => {
    if (!rzOn) return;
    const r = P.getBoundingClientRect();
    /* максимум считаем от ОКНА: на z.ai с открытым HTML-превью ширина документа
       уменьшается, и панель упиралась в этот уменьшенный предел */
    const wmax = Math.max(320, Math.round(innerWidth * 0.92));
    let w = rzSide === 'left' ? (r.right - e.clientX) : (e.clientX - r.left);
    w = Math.max(320, Math.min(wmax, Math.round(w)));
    P.style.width = w + 'px';
    P.style.maxWidth = wmax + 'px';
    UI.w = w;
    if (UI.dock && panelVisible()) setPageMargin(w);
  });
  addEventListener('mouseup', () => {
    if (!rzOn) return;
    rzOn = false;
    stopShield();
    try { document.body.style.cursor = ''; document.body.style.userSelect = ''; } catch (e) {}
    positionGrip(); saveUI();
  });

  /* перетаскивание + служебные кнопки (capture, сайт не перехватит) */
  (function () {
    const hd = $('#hd'); let dx = 0, dy = 0, drag = false;
    hd.addEventListener('mousedown', e => {
      if (e.target.closest('button, input')) return;
      const r0 = P.getBoundingClientRect();
      if (UI.dock) {                       // открепляем ПРИ ПЕРЕТАСКИВАНИИ — без прыжка: остаётся под курсором
        UI.dock = null; saveUI(); applyDock();
        P.style.left = Math.round(r0.left) + 'px';
        P.style.top = Math.max(0, Math.round(r0.top)) + 'px';
        positionGrip();
      }
      drag = true;
      dx = e.clientX - r0.left; dy = e.clientY - r0.top;
      P.style.right = 'auto';
      e.preventDefault();
    });
    addEventListener('mousemove', e => { if (!drag) return;
      P.style.left = Math.max(0, Math.min(innerWidth - 60, e.clientX - dx)) + 'px';
      P.style.top = Math.max(0, Math.min(innerHeight - 30, e.clientY - dy)) + 'px'; });
    addEventListener('mouseup', () => { if (drag) { drag = false; positionGrip(); } });
    P.addEventListener('click', e => {
      const a = e.target && e.target.dataset ? e.target.dataset.a : null;
      if (!a) return;
      e.preventDefault(); e.stopPropagation();
      if (a === 'close') {
        uninstall();                      // полная выгрузка: панель, стили, таймеры, перехват fetch
        return;
      }
      if (a === 'left') {
        if (UI.dock) { UI.dock = 'left'; saveUI(); applyDock(); }
        else { P.style.left = '8px'; P.style.right = 'auto'; P.style.top = '8px'; }
      }
      if (a === 'right') {
        if (UI.dock) { UI.dock = 'right'; saveUI(); applyDock(); }
        else { P.style.right = '8px'; P.style.left = 'auto'; P.style.top = '8px'; }
      }
      if (a === 'min') {
        const b = $('#bodyMain'), b2 = $('#bodySet'), tabs = P.querySelector('.wzrTabs');
        const hide = !P.classList.contains('wzrCollapsed');   // состояние берём из класса, а не из display
        P.classList.toggle('wzrCollapsed', hide);
        b.style.display = hide ? 'none' : (UI.tab === 'main' ? 'flex' : 'none');
        b2.style.display = hide ? 'none' : (UI.tab === 'set' ? '' : 'none');
        b.classList.toggle('wzrHidden', hide || UI.tab !== 'main');
        b2.classList.toggle('wzrHidden', hide || UI.tab !== 'set');
        tabs.style.display = hide ? 'none' : '';
        if (UI.dock) { P.style.height = hide ? 'auto' : '100vh'; P.style.bottom = hide ? 'auto' : '0'; }
        else { P.style.height = hide ? 'auto' : floatH() + 'px'; P.style.maxHeight = panelMaxH() + 'px'; }
        setPageMargin(hide ? 0 : (UI.dock && panelVisible() ? dockWidth() : 0));
      }
    }, true);
  })();

  /* -------------------------------- ДЕРЕВО --------------------------------- */
  function visible() {
    const fl = ($('#fl').value || '').trim().toLowerCase();
    return fl ? PATHS.filter(p => p.toLowerCase().includes(fl)) : PATHS.slice();
  }
  function buildDirSizes() {
    const D = new Map();
    for (const p of PATHS) {
      const s = shownSizeOf(p);
      const parts = p.split('/'); let pre = '';
      for (let i = 0; i < parts.length - 1; i++) {
        pre += parts[i] + '/';
        let e = D.get(pre);
        if (!e) { e = { sum: 0, unk: 0, known: 0 }; D.set(pre, e); }
        if (s == null) e.unk++; else { e.sum += s; e.known++; }
      }
    }
    return D;
  }
  function fileSz(p) { const s = shownSizeOf(p); return s == null ? '—' : human(s); }
  function dirSz(d) {
    const e = curDirSizes.get(d.endsWith('/') ? d : d + '/');
    if (!e) return '';
    if (!e.known) return e.unk ? '…' : '';               // размеры ещё не определены
    return (e.unk ? '≈' : '') + human(e.sum);            // 0 Б у пустых папок тоже показываем
  }
  const TREE_STEP = 4000;          // сколько строк дерева показываем за раз
  let TREE_LIMIT = 0;              // 0 = первая порция; растёт кнопкой и прокруткой
  function renderTree() {
    if (DEAD) return;
    applyFontMode();
    curDirSizes = buildDirSizes();
    const vis = visible();
    const limit = TREE_LIMIT || TREE_STEP;
    const shown = vis.length > limit ? vis.slice(0, limit) : vis;
    const rest = vis.length - shown.length;
    const root = { dirs: new Map(), files: [] };
    for (const p of shown) {
      const parts = p.split('/'); let node = root;
      for (let i = 0; i < parts.length - 1; i++) {
        if (!node.dirs.has(parts[i])) node.dirs.set(parts[i], { dirs: new Map(), files: [] });
        node = node.dirs.get(parts[i]);
      }
      node.files.push(parts[parts.length - 1]);
    }
    function build(node, prefix) {
      let s = '';
      const dirEntries = [...node.dirs.entries()];
      const dsum = nm => { const d = curDirSizes.get(prefix + nm + '/'); return d ? d.sum : 0; };
      if (UI.sort === 'alpha') dirEntries.sort((a, b) => a[0].localeCompare(b[0]));
      else if (UI.sort === 'size') dirEntries.sort((a, b) => (dsum(b[0]) - dsum(a[0])) || a[0].localeCompare(b[0]));
      for (const [name, sub] of dirEntries) {
        const dp = prefix + name;
        s += '<details data-dir="' + esc(dp) + '"' + (OPEN_DIRS.has(dp) ? ' open' : '') + '>' +
          '<summary data-dirsum="' + esc(dp) + '">' +
          '<span class="wzrArw">▶</span><input type="checkbox" data-dir="' + esc(dp) + '"> 📁 <b class="wzrNm">' + esc(name) + '</b>' +
          '<span class="wzrSz" data-szd="' + esc(dp) + '">' + dirSz(dp) + '</span></summary>' +
          '<div style="margin-left:16px">' + build(sub, dp + '/') + '</div></details>';
      }
      const files = node.files.slice();
      const fsize = f => { const v = sizeOf(prefix + f); return v == null ? -1 : v; };
      if (UI.sort === 'alpha') files.sort((a, b) => a.localeCompare(b));
      else if (UI.sort === 'size') files.sort((a, b) => (fsize(b) - fsize(a)) || a.localeCompare(b));
      for (const f of files) {
        const fp = prefix + f;
        s += '<div class="wzrRow" data-p="' + esc(fp) + '"><span class="wzrArw"></span>' +
          '<input type="checkbox" data-p="' + esc(fp) + '"' + (SEL.has(fp) ? ' checked' : '') + '> ' +
          '<span class="wzrNm">' + esc(f) + '</span><span class="wzrSz" data-sz="' + esc(fp) + '">' + fileSz(fp) + '</span></div>';
      }
      return s;
    }
    if (firstRender) {
      /* при самом первом показе — раскрыть верхний уровень; дальше состояние хранится в OPEN_DIRS */
      for (const name of root.dirs.keys()) OPEN_DIRS.add(name);
      firstRender = false;
    }
    const more = rest > 0
      ? '<div id="moreRows" style="color:#e0b060;padding:6px 4px">показано ' + shown.length + ' из ' + vis.length +
        ' — <button id="moreBtn" style="margin-left:4px">показать ещё ' + Math.min(rest, TREE_STEP) + '</button></div>'
      : '';
    const el = $('#tree');
    const keepTop = el.scrollTop;
    el.innerHTML = (build(root, '') + more) || '<i>пусто — нажмите ОБНОВИТЬ</i>';
    el.scrollTop = keepTop;
    const mb = $('#moreBtn');
    if (mb) mb.onclick = () => { TREE_LIMIT = (TREE_LIMIT || TREE_STEP) + TREE_STEP; renderTree(); };
    syncDirs(); stat(); updateMem(); fitLater();
  }
  /* прокрутка списка вниз догружает следующую порцию — как лента */
  $('#tree').addEventListener('scroll', () => {
    const el = $('#tree');
    if (el.scrollTop + el.clientHeight < el.scrollHeight - 80) return;
    const total = visible().length;
    if (total > (TREE_LIMIT || TREE_STEP)) { TREE_LIMIT = (TREE_LIMIT || TREE_STEP) + TREE_STEP; renderTree(); }
  });
  $('#tree').addEventListener('toggle', e => {
    const d = e.target;
    if (d && d.tagName === 'DETAILS' && d.dataset.dir) { d.open ? OPEN_DIRS.add(d.dataset.dir) : OPEN_DIRS.delete(d.dataset.dir); }
  }, true);
  function descendants(dir) { const pre = dir + '/'; return PATHS.filter(p => p === dir || p.startsWith(pre)); }
  /* Один проход по путям вместо фильтра на каждую папку: на тысячах файлов
     прежний вариант давал квадратичную сложность и заметно подвисал. */
  function dirCounts() {
    const C = new Map();
    for (const p of PATHS) {
      const on = SEL.has(p);
      const parts = p.split('/'); let pre = '';
      for (let i = 0; i < parts.length - 1; i++) {
        pre = pre ? pre + '/' + parts[i] : parts[i];
        let e = C.get(pre);
        if (!e) { e = { all: 0, on: 0 }; C.set(pre, e); }
        e.all++; if (on) e.on++;
      }
    }
    return C;
  }
  function syncDirs() {
    const C = dirCounts();
    for (const cb of $('#tree').querySelectorAll('input[data-dir]')) {
      const e = C.get(cb.dataset.dir) || { all: 0, on: 0 };
      cb.checked = e.all > 0 && e.on === e.all;
      cb.indeterminate = e.on > 0 && e.on < e.all;
    }
  }
  function selSize(sel, shown) { let sz = 0, unk = 0; for (const p of sel) { const s = shown ? shownSizeOf(p) : sizeOf(p); if (s == null) unk++; else sz += s; } return { sz, unk }; }
  function stat() {
    if (DEAD) return;
    const vis = visible();
    const selAll = [...SEL];                // «отмечено» — по ВСЕМ выбранным, а не только видимым в фильтре
    const selVis = vis.filter(p => SEL.has(p));
    const { sz, unk } = selSize(selAll, true);
    const withUrl = PATHS.filter(p => urlFor(p)).length;
    const filtering = ($('#fl').value || '').trim().length > 0;
    let sizeTxt = '';
    if (selAll.length && showingSizes()) {
      if (sz) sizeTxt = (unk ? '≈' : '') + human(sz);
      if (unk) sizeTxt += (sizeTxt ? ' + ' : '') + unk + ' без размера';
    }
    $('#stat').textContent = 'отмечено ' + selAll.length + ' из ' + PATHS.length +
      (filtering ? ' (в фильтре ' + selVis.length + ')' : '') +
      (sizeTxt ? ' · ' + sizeTxt : '') +
      ' | со ссылками: ' + withUrl + (TEMPLATE ? ' | шаблон пойман' : '');
    $('#go').title = selAll.length
      ? 'Скачать ' + selAll.length + ' файл(ов) одним ZIP' + (sizeTxt ? ', ' + sizeTxt : '')
      : 'Скачать отмеченное одним ZIP';
    paintToggle();
  }
  function updateAllSizes() {
    curDirSizes = buildDirSizes();
    for (const el of P.querySelectorAll('[data-sz]')) el.textContent = fileSz(el.dataset.sz);
    for (const el of P.querySelectorAll('[data-szd]')) el.textContent = dirSz(el.dataset.szd);
  }
  $('#tree').addEventListener('change', e => {
    const t = e.target;
    if (t.dataset.p) { t.checked ? SEL.add(t.dataset.p) : SEL.delete(t.dataset.p); }
    else if (t.dataset.dir !== undefined) {
      for (const p of descendants(t.dataset.dir)) t.checked ? SEL.add(p) : SEL.delete(p);
      for (const cb of $('#tree').querySelectorAll('input[data-p]'))
        if (cb.dataset.p.startsWith(t.dataset.dir + '/') || cb.dataset.p === t.dataset.dir) cb.checked = t.checked;
    }
    syncDirs(); stat();          // без renderTree — папки НЕ разворачиваются (п.2)
  });

  /* --------------------------- превью картинок ----------------------------- */
  const IMG_EXT = /\.(png|jpe?g|gif|webp|svg|bmp|ico)$/i;
  const prevCache = new Map();
  let prevEl = null, prevTimer = null, prevPath = null;
  function prevHide() { if (prevEl) { prevEl.remove(); prevEl = null; } prevPath = null; }
  async function cappedFetch(u, cap) {          // не качать больше cap байт (для превью)
    const ac = newAbort();
    try {
      const r = await fetch(u, { credentials: 'include', signal: ac.signal });
      if (!r.ok) return null;
      const cl = +(r.headers.get('content-length') || 0);
      if (cl && cl > cap) { try { r.body && r.body.cancel(); } catch (e) {} return null; }
      const rd = r.body.getReader(); const chunks = []; let n = 0;
      for (;;) { const { done, value } = await rd.read(); if (done) break; chunks.push(value); n += value.length; if (n > cap) { ac.abort(); return null; } }
      const out = new Uint8Array(n); let o = 0; for (const c of chunks) { out.set(c, o); o += c.length; }
      return out;
    } catch (e) { return null; }
  }
  function prevShow(p, x, y) {
    prevHide(); prevPath = p;
    prevEl = document.createElement('div');
    prevEl.style.cssText = 'position:fixed;z-index:2147483647;width:84px;height:84px;background:#0d0d16;border:1px solid #3a3a55;'
      + 'border-radius:6px;overflow:hidden;pointer-events:none;box-shadow:0 4px 14px rgba(0,0,0,.5);'
      + 'left:' + Math.min(innerWidth - 92, x + 14) + 'px;top:' + Math.min(innerHeight - 92, y + 10) + 'px';
    const img = document.createElement('div');
    img.style.cssText = 'width:100%;height:100%;display:flex;align-items:center;justify-content:center;color:#8fb7ff;font:12px monospace';
    img.textContent = '…'; prevEl.appendChild(img); document.body.appendChild(prevEl);
    const show = u => { if (prevPath !== p || !prevEl) return; const im = new Image(); im.style.cssText = 'width:100%;height:100%;object-fit:cover;display:block'; im.src = u; prevEl.innerHTML = ''; prevEl.appendChild(im); };
    if (prevCache.has(p)) { show(prevCache.get(p)); return; }
    const known = sizeOf(p);
    if (known != null && known > 8 * 1024 * 1024) { img.textContent = human(known) + ' — превью откл. (крупный)'; return; }
    if (prevCache.size > 60) { for (const u of prevCache.values()) { try { URL.revokeObjectURL(u); } catch (e) {} } prevCache.clear(); }
    const u = urlFor(p);
    if (u && /^https?:/.test(u) && new URL(u, location.href).hostname !== location.hostname) { show(u); return; }   // прямой CDN
    (async () => {
      let bytes = null;
      if (u && /^https?:|^\/|^\./.test(u) && !u.startsWith('zai:')) bytes = await cappedFetch(u, 4 * 1024 * 1024);
      if (!bytes) { const r = await fetchBytes(p); if (r instanceof Uint8Array) bytes = r; }
      if (bytes) {
        const bu = URL.createObjectURL(new Blob([bytes], { type: mimeFor(p) }));
        prevCache.set(p, bu); show(bu);
      } else if (prevPath === p && prevEl) img.textContent = 'нет превью';
    })();
  }
  $('#tree').addEventListener('mouseover', e => {
    const t = e.target.closest ? e.target.closest('[data-p]') : null;
    if (!t || !IMG_EXT.test(t.dataset.p)) return;
    const p = t.dataset.p, x = e.clientX, y = e.clientY;
    if (prevPath === p && prevEl) return;
    clearTimeout(prevTimer); prevTimer = setTimeout(() => prevShow(p, x, y), 160);
  });
  $('#tree').addEventListener('mouseout', () => { clearTimeout(prevTimer); prevHide(); });

  /* ------------------------- контекстное меню (п.4) ------------------------ */
  const CM = document.createElement('div');
  CM.id = 'wzrCM';
  document.body.appendChild(CM);
  function hideCM() { CM.style.display = 'none'; }
  function showCM(x, y, items) {
    CM.innerHTML = '';
    for (const it of items) {
      const d = document.createElement('div');
      d.className = 'wzrCMi'; d.textContent = it.t;
      d.onclick = () => { hideCM(); it.f(); };
      CM.appendChild(d);
    }
    CM.style.display = 'block';
    const r = CM.getBoundingClientRect();
    CM.style.left = Math.max(2, Math.min(innerWidth - r.width - 4, x)) + 'px';
    CM.style.top = Math.max(2, Math.min(innerHeight - r.height - 4, y)) + 'px';
  }
  /* ------------------- кодировка текста при просмотре ---------------------- */
  const TEXT_EXT = /\.(html?|xhtml|txt|md|markdown|css|js|mjs|cjs|jsx|ts|tsx|json|jsonc|xml|svg|csv|tsv|yml|yaml|ini|cfg|conf|toml|log|sql|py|rb|php|java|c|h|cpp|hpp|cs|go|rs|sh|bat|ps1|srt|vtt|ass)$/i;
  const BOM_UTF8 = u => u.length >= 3 && u[0] === 0xEF && u[1] === 0xBB && u[2] === 0xBF;
  const BOM_UTF16LE = u => u.length >= 2 && u[0] === 0xFF && u[1] === 0xFE;
  const BOM_UTF16BE = u => u.length >= 2 && u[0] === 0xFE && u[1] === 0xFF;
  function decodeText(bytes) {
    /* 1) BOM — самый надёжный признак; 2) объявленная в файле кодировка;
       3) строгий UTF-8; 4) windows-1251 как частый вариант для русских файлов. */
    if (BOM_UTF16LE(bytes)) return { text: new TextDecoder('utf-16le').decode(bytes.subarray(2)), enc: 'utf-16le (BOM)' };
    if (BOM_UTF16BE(bytes)) return { text: new TextDecoder('utf-16be').decode(bytes.subarray(2)), enc: 'utf-16be (BOM)' };
    if (BOM_UTF8(bytes)) return { text: new TextDecoder('utf-8').decode(bytes.subarray(3)), enc: 'utf-8 (BOM)' };
    const head = new TextDecoder('windows-1252').decode(bytes.subarray(0, 4096));
    const declared = (head.match(/charset\s*=\s*["']?\s*([A-Za-z0-9_-]+)/i) || [])[1];
    if (declared && !/^utf-?8$/i.test(declared)) {
      try { return { text: new TextDecoder(declared.toLowerCase(), { fatal: true }).decode(bytes), enc: declared.toLowerCase() }; }
      catch (e) { /* заявленная кодировка не подошла — идём дальше */ }
    }
    try { return { text: new TextDecoder('utf-8', { fatal: true }).decode(bytes), enc: 'utf-8' }; }
    catch (e) { return { text: new TextDecoder('windows-1251').decode(bytes), enc: 'windows-1251' }; }
  }
  /* HTML: кодировку в документе принудительно переводим в UTF-8, иначе браузер
     прочитает старый <meta charset="windows-1251"> и снова покажет «иероглифы». */
  function htmlAsUtf8(text) {
    const meta = '<meta charset="utf-8">';
    let out = text.replace(/<meta[^>]*charset\s*=\s*["']?[A-Za-z0-9_-]+["']?[^>]*>/gi, '');
    if (/<head[^>]*>/i.test(out)) return out.replace(/<head[^>]*>/i, m => m + meta);
    if (/<html[^>]*>/i.test(out)) return out.replace(/<html[^>]*>/i, m => m + '<head>' + meta + '</head>');
    return meta + out;
  }
  function viewBlob(p, bytes) {
    const name = p.split('/').pop();
    if (!TEXT_EXT.test(name)) return { blob: new Blob([bytes], { type: mimeFor(name) }), enc: null };
    const { text, enc } = decodeText(bytes);
    if (/\.(html?|xhtml)$/i.test(name)) return { blob: new Blob([htmlAsUtf8(text)], { type: 'text/html;charset=utf-8' }), enc };
    if (/\.svg$/i.test(name)) return { blob: new Blob([text], { type: 'image/svg+xml;charset=utf-8' }), enc };
    const type = (/\.(json|jsonc)$/i.test(name) ? 'application/json' : 'text/plain') + ';charset=utf-8';
    return { blob: new Blob([text], { type }), enc };
  }
  async function openFile(p) {
    const u = urlFor(p);
    const abs = u ? absUrl(u) : null;
    let cross = false;
    try { cross = !!abs && /^https?:/.test(abs) && new URL(abs).hostname !== location.hostname; } catch (e) {}
    /* HTML/текст даже с чужого CDN прогоняем через перекодировку, иначе сервер
       может отдать его без charset — браузер покажет кракозябры. */
    if (cross && !TEXT_EXT.test(p.split('/').pop())) { window.open(abs, '_blank', 'noopener'); return; }
    const w = window.open('about:blank', '_blank');       // открываем СРАЗУ (иначе попап-блокер)
    try { w.document.title = 'Загрузка…'; w.document.body.style.background = '#111'; } catch (e) {}
    const b = await fetchBytes(p);
    if (b instanceof Uint8Array) {
      const { blob, enc } = viewBlob(p, b);
      const bu = URL.createObjectURL(blob);
      if (w && !w.closed) w.location.href = bu; else window.open(bu, '_blank');
      setTimeout(() => URL.revokeObjectURL(bu), 10 * 60 * 1000);
      if (enc) log('Открыт «' + p.split('/').pop() + '»: исходная кодировка ' + enc + ' → показан как UTF-8.');
    } else if (cross) {
      if (w && !w.closed) w.location.href = abs; else window.open(abs, '_blank', 'noopener');
      log('Байты файла недоступны странице (CORS) — открыл прямую ссылку CDN: ' + p.split('/').pop());
    } else {
      if (w) w.close();
      log('Не удалось открыть «' + p.split('/').pop() + '»: ' + (b && b.http ? 'HTTP ' + b.http : (b && b.err) || 'нет ссылки'));
    }
  }
  async function copyLink(p) {
    const u = urlFor(p);
    if (u && !u.startsWith('zai:') && !u.startsWith('blob:')) { await copyText(absUrl(u), 'Прямая ссылка скопирована: ' + p.split('/').pop()); return; }
    log('Прямой URL у файла нет (доступ через API сайта) — беру байты и копирую временную blob-ссылку…');
    const b = await fetchBytes(p);
    if (b instanceof Uint8Array) {
      const bu = URL.createObjectURL(new Blob([b], { type: mimeFor(p) }));
      await copyText(bu, 'Скопирована временная ссылка (blob) — работает только в этом браузере, пока жива вкладка.');
    } else log('Не удалось получить файл для ссылки: ' + p);
  }
  /* оглавление папки: генерируем аккуратную страницу-список с прямыми ссылками */
  function openDirIndex(dir) {
    const items = PATHS.filter(p => p.startsWith(dir + '/'));
    if (!items.length) { log('В папке нет известных файлов: ' + dir); return; }
    let known = 0, tot = 0;
    const rows = items.map(p => {
      const rel = p.slice(dir.length + 1);
      const u = urlFor(p);
      const sz = sizeOf(p); if (sz != null) { known++; tot += sz; }
      const link = (u && !u.startsWith('zai:') && !u.startsWith('blob:'))
        ? '<a href="' + esc(absUrl(u)) + '" target="_blank" rel="noopener" style="color:#8fb7ff">' + esc(rel) + '</a>'
        : '<span>' + esc(rel) + '</span> <i style="color:#777">(байты доступны только через панель: API сайта)</i>';
      return '<li style="margin:3px 0">' + link + (sz != null ? ' — <b style="color:#7fbf7f">' + human(sz) + '</b>' : '') + '</li>';
    }).join('');
    const page = '<!DOCTYPE html><html lang="ru"><head><meta charset="utf-8"><title>' + esc(dir) + '</title></head>' +
      '<body style="background:#141420;color:#eee;font:16px/1.6 system-ui,Arial;padding:26px">' +
      '<div style="max-width:900px;margin:0 auto"><h2 style="color:#8fe38f">📂 ' + esc(dir) + '</h2>' +
      '<p>Файлов: ' + items.length + (known ? ' · суммарно ≈' + human(tot) : '') + '</p><ul style="padding-left:22px">' + rows + '</ul>' +
      '<p style="color:#777;font-size:14px;margin-top:20px">Сгенерировано Workspace Rescue V1 · ссылки открываются вашей сессией сайта</p></div></body></html>';
    const w = window.open('about:blank', '_blank');
    const bu = URL.createObjectURL(new Blob([page], { type: 'text/html;charset=utf-8' }));
    if (w && !w.closed) w.location.href = bu; else window.open(bu, '_blank');
    setTimeout(() => URL.revokeObjectURL(bu), 10 * 60 * 1000);
    log('Оглавление папки открыто во вкладке: ' + dir + ' (' + items.length + ' файлов)');
  }
  async function saveOneLogged(p) {
    if (busy) { log('Идёт скачивание — дождитесь окончания или нажмите СТОП.'); return; }
    busy = true; STOP = false; runAC = newAbort(); $('#stop').style.display = '';
    log('Скачиваю файл: ' + p);
    progShow('скачиваю: ' + p.split('/').pop(), 0, true);
    const ok = await saveOne(p, runAC.signal);
    busy = false; runAC = null; $('#stop').style.display = 'none';
    if (ok) { log('Готово: ' + p.split('/').pop(), 'ok'); progDone('Сохранено: ' + p.split('/').pop()); }
    else { progHide(); log(STOP ? 'Отменено.' : 'Ошибка скачивания: ' + p); }
  }
  $('#tree').addEventListener('contextmenu', e => {
    const frow = e.target.closest ? e.target.closest('[data-p]') : null;
    if (frow) {
      e.preventDefault();
      const p = frow.dataset.p;
      showCM(e.clientX, e.clientY, [
        { t: '🔗 Открыть в новой вкладке', f: () => openFile(p) },
        { t: '📋 Копировать прямую ссылку', f: () => copyLink(p) },
        { t: '⬇️ Скачать файл', f: () => saveOneLogged(p) },
        { t: '📄 Копировать путь', f: () => copyText(p, 'Путь скопирован.') }
      ]);
      return;
    }
    const dsum = e.target.closest ? e.target.closest('[data-dirsum]') : null;
    if (dsum) {
      e.preventDefault();
      const d = dsum.dataset.dirsum;
      showCM(e.clientX, e.clientY, [
        { t: '📂 Оглавление папки (вкладка)', f: () => openDirIndex(d) },
        { t: '🌐 Страница чата на сайте', f: () => window.open(location.href.split('?')[0], '_blank', 'noopener') },
        { t: '📄 Копировать путь папки', f: () => copyText(d, 'Путь папки скопирован.') },
        { t: '☑ Отметить папку', f: () => { for (const q of descendants(d)) SEL.add(q); syncDirs(); stat(); syncFileChecks(); } },
        { t: '☐ Снять отметку с папки', f: () => { for (const q of descendants(d)) SEL.delete(q); syncDirs(); stat(); syncFileChecks(); } }
      ]);
    }
  });
  function syncFileChecks() {
    for (const cb of $('#tree').querySelectorAll('input[data-p]')) cb.checked = SEL.has(cb.dataset.p);
  }
  document.addEventListener('click', e => { if (!CM.contains(e.target)) hideCM(); }, true);
  document.addEventListener('scroll', hideCM, true);
  addEventListener('keydown', e => { if (e.key === 'Escape') hideCM(); });
  addEventListener('resize', () => { hideCM(); if (UI.dock) applyDock(); else fitLater(); });

  /* ------------------------------ фильтр/всё ------------------------------- */
  let flT = null;
  $('#fl').oninput = () => { clearTimeout(flT); TREE_LIMIT = 0; flT = setTimeout(renderTree, 150); };   // дебаунс — не тормозим набор
  const SORTS = ['alpha', 'size', 'none'];
  const SORT_LABEL = { alpha: 'СОРТ: А-Я', size: 'СОРТ: РАЗМЕР', none: 'СОРТ: СЕРВЕР' };
  function applySortLabel() { $('#sortBtn').textContent = SORT_LABEL[UI.sort] || SORT_LABEL.alpha; }
  $('#sortBtn').onclick = () => {
    UI.sort = SORTS[(SORTS.indexOf(UI.sort) + 1) % SORTS.length];
    saveUI(); applySortLabel(); renderTree();
    log('сортировка: ' + (UI.sort === 'alpha' ? 'А-Я' : UI.sort === 'size' ? 'по размеру' : 'как на сервере'));
  };
  /* одна кнопка-переключатель: всё отмечено — снимает, иначе отмечает всё */
  function toggleAll() {
    const vis = visible();
    const allOn = vis.length > 0 && vis.every(p => SEL.has(p));
    for (const p of vis) { if (allOn) SEL.delete(p); else SEL.add(p); }
    syncFileChecks(); syncDirs(); stat();
  }
  $('#all').onclick = toggleAll;
  /* значок показывает состояние: ☑ всё отмечено / ☐ ничего */
  function paintToggle() {
    const b = $('#all'); if (!b) return;
    const vis = visible();
    const allOn = vis.length > 0 && vis.every(p => SEL.has(p));
    b.textContent = allOn ? '\u2610' : '\u2611';
    b.title = allOn ? 'Снять все отметки' : 'Отметить всё (все файлы списка)';
  }

  /* --------------------------- шкала памяти (п.16) -------------------------- */
  function updateMem() {
    if (DEAD) return;
    if (!showingSizes()) {
      const t0 = $('#memTxt'), f0 = $('#memFill');
      if (t0) t0.textContent = 'память: подсчёт размеров выключен (включить — НАСТРОЙКИ)';
      if (f0) f0.style.width = '0';
      return;
    }
    let used = 0, unk = 0;
    for (const p of PATHS) { const s = shownSizeOf(p); if (s == null) unk++; else used += s; }
    if (quotaHint && typeof quotaHint.used === 'number') used = Math.max(used, quotaHint.used);
    let total = 0;
    if (UI.quotaGB > 0) total = UI.quotaGB * 1073741824;
    else if (quotaHint && quotaHint.total) total = quotaHint.total;
    else if (quotaHint && quotaHint.free != null) total = used + quotaHint.free;
    const txt = $('#memTxt'), fill = $('#memFill');
    if (!PATHS.length) { txt.textContent = 'память: список пуст — нажмите ОБНОВИТЬ'; fill.style.width = '0'; return; }
    const files = ' · файлов: ' + PATHS.length + (unk ? ' (без размера: ' + unk + ')' : '');
    if (total > 0) {
      const pct = Math.max(0, Math.min(100, used / total * 100));
      const srcTag = UI.quotaGB > 0 ? ' (объём из настроек)' : ((quotaHint && quotaHint.src === 'api') ? ' (объём из API сайта)' : '');
      txt.textContent = 'память области: занято ~' + human(used) + ' из ' + human(total) + ' · свободно ~' + human(Math.max(0, total - used)) + srcTag + (unk ? ' (у ' + unk + ' файлов размер не определён)' : '');
      fill.style.width = pct.toFixed(1) + '%';
      fill.style.background = pct > 90 ? '#c04545' : pct > 70 ? '#c09045' : '#3aa757';
    } else {
      txt.textContent = 'занято ~' + human(used) + files + ' · общий объём сайт не сообщает — можно задать в Настройках';
      fill.style.width = '0';
    }
  }

  /* ------------------------- определение размеров (п.3) --------------------- */
  let sizeBusy = false, sizeAC = null;
  async function probeSize(u, signal) {
    if (u.startsWith('zai:')) return await zaiContent(u.slice(4), signal, true);   // у z.ai размер знает только их API
    /* защита от «одинаковых 137 Б»: если сервер вместо файла отдал JSON-ошибку
       или HTML-заглушку — такой content-length за размер НЕ считаем */
    const abs = absUrl(u);
    const pth = abs.split('?')[0];
    const okCt = ct => {
      if (!ct) return true;
      ct = ct.toLowerCase();
      if (ct.includes('json')) return /\.(json|ipynb|webmanifest)$/i.test(pth);
      if (ct.includes('text/html')) return /\.(html?|xhtml)$/i.test(pth);
      if (ct.includes('text/plain') && /\.(png|jpe?g|gif|webp|zip|pdf|mp4|mp3)/i.test(pth)) return false;
      return true;
    };
    try {
      const r = await fetch(abs, { method: 'HEAD', credentials: 'include', signal });
      if (r.ok && okCt(r.headers.get('content-type'))) { const cl = r.headers.get('content-length'); if (cl) return +cl; }
    } catch (e) {}
    try {
      const r = await fetch(abs, { method: 'GET', credentials: 'include', signal, headers: { Range: 'bytes=0-0' } });
      const cr = r.headers.get('content-range');
      const ct = r.headers.get('content-type');
      try { r.body && r.body.cancel(); } catch (e) {}
      if ((r.status === 206 || r.ok) && okCt(ct)) {
        if (cr) { const m = /\/(\d+)\s*$/.exec(cr); if (m) return +m[1]; }
        const cl = r.headers.get('content-length');
        if (r.status !== 206 && cl) return +cl;
      }
    } catch (e) {}
    try {   /* последний шанс: обычный GET — читаем только заголовки и сразу гасим тело */
      const r = await fetch(abs, { credentials: 'include', signal });
      const cl = r.headers.get('content-length');
      const ct = r.headers.get('content-type');
      try { r.body && r.body.cancel(); } catch (e) {}
      if (r.ok && cl && okCt(ct)) return +cl;
    } catch (e) {}
    if (HAS_BRIDGE) { const s = await extSize(abs); if (s != null) return s; }
    return null;
  }
  async function resolveSizes(manual) {
    if (sizeBusy) return;
    const mode = UI.sizesMode || 'full';
    if (!manual && mode === 'off') return;   // размеры выключены — сайт не беспокоим
    if (manual) NEG.clear();                 // ручной запрос перепроверяет и неудавшиеся файлы
    for (const k of Object.keys(PROBE_WHY)) delete PROBE_WHY[k];
    PROBE_BUDGET = 32 * 1024 * 1024;         // бюджет подсчёта — на каждый круг свой
    const limit = manual ? 800 : 400;
    const todo = [];
    for (const p of PATHS) {
      if (SIZEMAP.has(p) || NEG.has(p)) continue;         // точный размер важнее совпадения по имени
      const u = urlFor(p);
      if (!u || u.startsWith('blob:')) continue;          // z.ai тоже пробуем — см. probeSize
      todo.push([p, u]);
      if (todo.length >= limit) break;
    }
    if (!todo.length) { if (manual) log('Размеры уже определены (или недоступны для этого сайта).'); return; }
    sizeBusy = true;
    if (manual) log('Запрашиваю размеры: ' + todo.length + ' файлов…');
    const ac = newAbort();
    sizeAC = ac;
    const q = todo.slice(); let got = 0;
    async function w() {
      while (q.length) {
        if (ac.signal.aborted) return;                  // СТОП прерывает и эту работу
        const [p, u] = q.shift();
        const s = await probeSize(u, ac.signal);
        if (okSize(s)) { setSize(p, s); got++; } else NEG.add(p);
      }
    }
    await Promise.all(Array.from({ length: WORKERS }, w));
    sizeBusy = false; sizeAC = null;
    updateAllSizes(); stat(); updateMem();
    if (manual) {
      log('Размеры получены для ' + got + ' из ' + todo.length + ' файлов' +
        (PATHS.length > todo.length ? ' (остальные — нажмите кнопку ещё раз)' : '') + '.', got < todo.length ? 'err' : 'ok');
      const why = Object.keys(PROBE_WHY).map(k => k + ' — ' + PROBE_WHY[k]).join(', ');
      if (why) log('Причины, по которым размер не определён: ' + why + '.', 'err');
    }
  }

  /* ------------------------------ ОБНОВИТЬ (п.6) --------------------------- */
  const KNOWN = new Set();
  function applyPaths(np) {
    const set = new Set(np);
    const added = [];
    for (const p of np) if (!KNOWN.has(p)) { KNOWN.add(p); SEL.add(p); added.push(p); }
    for (const p of [...KNOWN]) if (!set.has(p)) KNOWN.delete(p);
    for (const p of [...SEL]) if (!KNOWN.has(p)) SEL.delete(p);
    PATHS = [...new Set(np)];           // порядок сервера сохраняем (для режима «без сортировки»)
    PATH_IDX_GEN++;                     // индекс путей для поиска шаблона устарел
    return added;
  }
  async function refresh(quiet) {
    if (DEAD) return;
    SILENT = !!quiet;
    try {
      pollPerf();
      let preset = [];
      if (IS_QWEN) {
        if (getChat()) {
          try {
            const r = await fetch('/api/v2/chat/' + qid() + '/workspace-files', { credentials: 'include' });
            const j = await r.json();
            scanQuota(j);
            let dw = j && j.data;
            if (dw && !Array.isArray(dw)) dw = dw.files || dw.paths || dw.list || dw.items || dw.tree || null;
            for (const x of (Array.isArray(dw) ? dw : [])) {
              if (typeof x === 'string') { const rel = normPath(x); if (rel) preset.push(rel); }
              else if (x && typeof x === 'object') {
                const nk = Object.keys(x).find(NAME_KEY);
                if (nk) {
                  const rel = normPath(x[nk]);
                  if (rel) {
                    preset.push(rel);
                    const sk = Object.keys(x).find(k => SIZE_KEY(k) && okSize(x[k]));
                    if (sk) setSize(rel, x[sk]);
                  }
                }
              }
            }
          } catch (e) { log('Пресет Qwen недоступен: ' + e.message); }
        }
        const hv = harvestQwen();
        for (const [k, v] of hv.map) if (!URLMAP.has(k)) URLMAP.set(k, v);
        if (hv.added) log('Qwen: подобрано CDN-ссылок (изображения/артефакты): +' + hv.added + ' (всего ' + hv.map.size + ')');
        if (hv.map.size) preset = [...new Set([...preset, ...hv.map.keys()])];
      }
      if (!preset.length && IS_ZAI) {
        const ms = location.pathname.match(/\/s\/([0-9a-f-]{8,})/i);
        if (!zaiToken()) log('Z.ai: нет токена — войдите в аккаунт и нажмите ОБНОВИТЬ.');
        else {
          setZaiTarget();
          await zaiFetchWsId();
          let lst = await zaiList();
          if (!lst.length && !quiet) {                    // тяжёлый пробуждающий цикл — только вручную
            log('Z.ai: workspace спит — бужу сам…');
            await zaiWake(); lst = await zaiList();
            for (let i = 0; i < 4 && !lst.length; i++) { await new Promise(r => setTimeout(r, 2500)); lst = await zaiList(); }
            if (!lst.length && zaiDiag.lsStatus === 429) {
              try { const rr = await fetch(location.origin + '/api/v1/web-dev/workspaces/restart', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + zaiToken() }, body: JSON.stringify({ chatId: zaiId }) }); zaiDiag.wake.push('restart:' + rr.status); } catch (e) {}
              for (let i = 0; i < 3 && !lst.length; i++) { await new Promise(r => setTimeout(r, 3000)); lst = await zaiList(); }
            }
          }
          preset = lst;
          if (!lst.length) log('Z.ai: список пуст. lsHTTP=' + zaiDiag.lsStatus + ' | ' + zaiDiag.lsBody.slice(0, 100));
        }
      }
      const before = PATHS.slice();
      let added = [];
      if (preset.length) { added = applyPaths(preset); }
      else { const d = discover(); added = applyPaths(d.paths); }
      $('#c').textContent = HOST.replace(/^www\./, '') + ' | чат ' + ((qid() || '?').slice(0, 8)) + '… | путей: ' + PATHS.length;
      const changed = PATHS.length !== before.length || PATHS.some((p, i) => p !== before[i]);
      SILENT = false;
      if (quiet) {
        /* п.9: в авто-режиме — только про новые файлы, ничего лишнего */
        if (changed) renderTree(); else { updateAllSizes(); stat(); updateMem(); }
        for (const p of added.slice(0, 8)) log('появился новый файл: ' + p, 'new');
        if (added.length > 8) log('…и ещё ' + (added.length - 8) + ' новых', 'new');
        if (showingSizes() && added.length) idle(() => resolveSizes(false));
        return;
      }
      renderTree();
      const withUrl = PATHS.filter(p => urlFor(p)).length;
      if (!PATHS.length) log('Путей 0. Сверните и раскройте панель файлов сайта (или чат туда-обратно), затем ОБНОВИТЬ.');
      else if (!withUrl) log('Пути есть, ссылок нет: ПОЙМАТЬ ССЫЛКУ и кликните скачивание одного файла.');
      else log('Обновлено: путей ' + PATHS.length + ', со ссылками ' + withUrl + '.');
      if (showingSizes()) idle(() => resolveSizes(false));
      updateMem();
    } catch (e) {
      SILENT = false;
      log('ОШИБКА ОБНОВЛЕНИЯ: ' + errRu(e.message), 'err');
    }
  }
  $('#refresh').onclick = () => { if (busy) { log('Идёт скачивание — сначала нажмите СТОП.'); return; } log('Обновляю список…'); refresh(false); };

  $('#arch').onclick = async () => {
    if (!IS_ZAI) { log('Серверный архив доступен только на chat.z.ai.'); return; }
    if (busy) { log('Уже идёт скачивание.'); return; }
    busy = true; STOP = false; runAC = newAbort(); $('#stop').style.display = '';
    log('Z.ai: запрашиваю серверный архив ВСЕЙ рабочей области…');
    progShow('сервер пакует архив…', 0, true);
    const blob = await zaiArchive();
    busy = false; runAC = null; $('#stop').style.display = 'none';
    if (STOP) { progHide(); log('Отменено.'); return; }
    if (blob && blob.size > 200) {
      const nm = 'zai_' + ((zaiId || 'workspace').slice(0, 8)) + '_' + new Date().toISOString().slice(0, 10) + '.zip';
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob); a.download = nm;
      document.body.appendChild(a); a.click();
      setTimeout(u => URL.revokeObjectURL(u), 10 * 60 * 1000, a.href);
      a.remove();
      log('ГОТОВО: ' + (blob.size / 1e6).toFixed(1) + ' МБ -> ' + nm + ' (ВСЯ область, независимо от галочек).', 'ok');
      progDone('ГОТОВО: ' + (blob.size / 1e6).toFixed(1) + ' МБ');
    } else { progHide(); log('Серверный архив не удался. Используйте СКАЧАТЬ ZIP.'); }
  };

  /* --------------------------- ПОЙМАТЬ ССЫЛКУ ------------------------------ */
  $('#catch').onclick = () => {
    if (IS_ZAI || IS_QWEN) { log('На этом сайте ловля не нужна: есть готовый пресет. Нажмите ОБНОВИТЬ, затем СКАЧАТЬ ZIP.'); return; }
    armed = extraUrls.length; pollPerf(); log('ЛОВЛЮ: кликните штатную кнопку скачивания ОДНОГО файла на сайте.');
  };
  /* Поиск шаблона ссылки. Раньше на каждый адрес перебирались ВСЕ файлы ×3
     варианта кодировки — на больших списках это заметно жгло процессор каждую
     секунду. Теперь есть индекс путей и набор закодированных путей: ищем хвост
     адреса по сегментам и значение параметра целиком. */
  let PATH_INDEX = new Set(), ENC_INDEX = new Map(), PATH_IDX_GEN = 0, PATH_IDX_USE = -1;
  function pathIndexes() {
    if (PATH_IDX_USE === PATH_IDX_GEN) return;
    PATH_IDX_USE = PATH_IDX_GEN;
    PATH_INDEX = new Set(PATHS);
    ENC_INDEX = new Map();
    for (const p of PATHS) ENC_INDEX.set(encodeURIComponent(p), p);
  }
  function matchPathInUrl(u) {
    pathIndexes();
    let url; try { url = new URL(u, location.href); } catch (e) { return null; }
    const parts = (url.pathname + url.search).split('/').filter(Boolean);
    for (let i = 0; i < parts.length; i++) {
      const raw = parts.slice(i).join('/');
      if (raw.length <= 4) continue;
      let dec = raw; try { dec = decodeURI(raw); } catch (e) { continue; }
      if (!PATH_INDEX.has(dec)) continue;
      const at = u.indexOf(raw);
      if (at < 0) continue;
      const tok = raw === dec ? '{R}' : (raw === encodeURIComponent(dec) ? '{E}' : '{P}');
      return { path: dec, at, len: raw.length, tok };
    }
    for (const pair of url.search.slice(1).split('&')) {
      const eq = pair.indexOf('=');
      if (eq < 0) continue;
      const v = pair.slice(eq + 1);
      const p = ENC_INDEX.get(v);
      if (p && p.length > 4) { const at = u.indexOf(v); if (at >= 0) return { path: p, at, len: v.length, tok: '{E}' }; }
    }
    return null;
  }
  const iTimerCap = setInterval(() => {
    if (DEAD) return;
    if (TEMPLATE || IS_QWEN || IS_ZAI || document.hidden) return;
    pollPerf();
    const pool = armed >= 0 ? extraUrls.slice(armed) : extraUrls.slice(-40);
    for (const { u } of pool.slice().reverse()) {
      const hit = matchPathInUrl(u);
      if (hit) {
        TEMPLATE = u.slice(0, hit.at) + hit.tok + u.slice(hit.at + hit.len);
        armed = -1;
        log('Шаблон пойман (' + u.slice(0, 60) + '…)');
        log('Теперь СКАЧАТЬ ZIP.');
        stat();
        return;
      }
      if (!PATHS.length && /^https?:/.test(u) && FILE_EXT.test(decodeURIComponent(new URL(u, location.href).pathname))) {
        const rel = relFromUrl(u);
        if (rel) { PATHS = [rel]; URLMAP.set(rel, u); SEL = new Set(PATHS); PATH_IDX_GEN++; renderTree();
          log('Пойман образец файла: ' + rel + '. Обновите список (ОБНОВИТЬ) для полноты.'); return; }
      }
    }
  }, 1000);

  /* --------------------- СКАЧАТЬ ZIP (п.7,8,10,18) -------------------------- */
  function zipBaseName(list) {
    /* имя — по ОБЩЕЙ папке выделения: всё внутри «1/3/» → «3.zip», а не «1.zip» */
    let base = '';
    if (list.length === 1) base = list[0].split('/').pop().replace(/\.[A-Za-z0-9]{1,10}$/, '');
    else {
      const split = list.map(p => p.split('/'));
      const first = split[0];
      let i = 0;
      while (i < first.length - 1 && split.every(s => s.length > i + 1 && s[i] === first[i])) i++;
      if (i > 0) base = first[i - 1];
    }
    if (!base) {
      const d = new Date(), z = n => String(n).padStart(2, '0');
      base = 'rescue_' + d.getFullYear() + '-' + z(d.getMonth() + 1) + '-' + z(d.getDate()) + '_' + z(d.getHours()) + z(d.getMinutes());
    }
    base = base.replace(/[\\/:*?"<>|\x00-\x1f]+/g, '_').replace(/^\.+/, '').slice(0, 80);
    return base || 'files';
  }
  $('#stop').onclick = () => {
    STOP = true;
    if (runAC) { try { runAC.abort(); } catch (e) {} }       // п.10: мгновенно рвём идущие запросы
    if (sizeAC) { try { sizeAC.abort(); } catch (e) {} }     // и запросы размеров тоже
    log('СТОП — отменяю…');
  };
  $('#go').onclick = async () => {
    if (busy) { log('Уже идёт.'); return; }
    const list = visible().filter(p => SEL.has(p) && urlFor(p));
    if (!list.length) { log('Нет отмеченных со ссылками. ОБНОВИТЬ или ПОЙМАТЬ ССЫЛКУ.'); return; }
    busy = true; STOP = false; runAC = newAbort(); $('#stop').style.display = '';
    progShow('подготовка…', 0, true);
    const signal = runAC.signal;
    const allSelected = PATHS.length > 0 && list.length === PATHS.length;
    if (IS_ZAI && zaiMode === 'chat' && allSelected) {
      log('Z.ai: отмечено ВСЁ — пробую серверный архив всей области (один запрос)…');
      progShow('сервер пакует архив всей области…', 0, true);
      const blob = await zaiArchive();
      if (!STOP && blob && blob.size > 200) {
        const nm = 'zai_' + ((zaiId || 'workspace').slice(0, 8)) + '_' + new Date().toISOString().slice(0, 10) + '.zip';
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob); a.download = nm;
        document.body.appendChild(a); a.click();
        setTimeout(u => URL.revokeObjectURL(u), 10 * 60 * 1000, a.href);
        a.remove();
        log('ГОТОВО: серверный архив ' + (blob.size / 1e6).toFixed(1) + ' МБ -> ' + nm, 'ok');
        progDone('ГОТОВО: серверный архив ' + (blob.size / 1e6).toFixed(1) + ' МБ');
        busy = false; runAC = null; $('#stop').style.display = 'none';
        return;
      }
      if (STOP) { progHide(); log('ОСТАНОВЛЕНО: отменено.'); busy = false; runAC = null; $('#stop').style.display = 'none'; return; }
      log('Серверный архив недоступен — качаю пофайлово выбранное.');
    }
    /* очень крупные одиночные файлы — мимо ZIP (п.18: без ограничений по объёму) */
    const huge = list.filter(p => (sizeOf(p) || 0) > HUGE_BYTES);
    const zipList = huge.length ? list.filter(p => !huge.includes(p)) : list;
    const base = zipBaseName(list);
    const { sz } = selSize(list);
    log('Качаю ВЫБРАННОЕ: ' + list.length + ' файлов' + (sz ? ', ~' + human(sz) : '') + ', в ' + WORKERS + ' потоков…');
    const q = zipList.slice();
    let batch = [], bb = 0, part = 1, done = 0, bad = 0, last = 0;
    let flushing = null;
    const t0 = Date.now();
    async function flush() {
      if (flushing) return flushing;
      if (!batch.length || STOP) { batch = []; bb = 0; return; }
      const entries = batch;
      batch = []; bb = 0;
      flushing = (async () => {
      progShow('сборка ZIP в фоне (' + entries.length + ' файлов)…', 100, true);
      const blob = await makeZipAsync(entries);
      if (STOP) return;
      if (!blob) { bad += entries.length; return; }     // архив не собрался — сообщаем, а не молчим
      const nm = (part === 1 ? base : base + '_part' + part) + '.zip';
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob); a.download = nm;
      document.body.appendChild(a); a.click();
      setTimeout(u => URL.revokeObjectURL(u), 10 * 60 * 1000, a.href);   // ссылка живёт до конца загрузки
      a.remove();
      log('АРХИВ ' + nm + ': ' + entries.length + ' файлов, ' + (blob.size / 1e6).toFixed(1) + ' МБ', 'ok');
      part++;
      await new Promise(r => setTimeout(r, 800));
      })();
      try { await flushing; } finally { flushing = null; }
    }
    async function worker() {
      while (q.length && !STOP) {
        const p = q.shift();
        try {
          const res = await fetchBytes(p, signal);
          if (flushing) await flushing;
          if (STOP) break;
          if (!res) { bad++; if (bad < 6) log('  нет ссылки: ' + p, 'err'); continue; }
          if (!(res instanceof Uint8Array)) { if (res.err !== 'abort') { bad++; if (bad < 6) log('  ' + (res.http ? 'HTTP ' + res.http : res.err) + ': ' + p, 'err'); } continue; }
          batch.push({ name: p, u8: res }); bb += res.length; done++;
          progShow('скачано ' + (done + bad) + ' из ' + list.length + ' · получено ' + human(bb) + ' · ' + (done / ((Date.now() - t0) / 1000)).toFixed(1) + ' файл/с', (done + bad) / list.length * 100);
          if (done - last >= 40) { last = done; log('  …' + done + '/' + zipList.length + '  (' + (done / ((Date.now() - t0) / 1000)).toFixed(1) + ' файл/с)'); }
          if (batch.length >= SPLIT_COUNT || bb >= SPLIT_BYTES) await flush();
        } catch (e) { if (!STOP) { bad++; if (bad < 6) log('  ошибка ' + p + ': ' + errRu(e.message), 'err'); } }
      }
    }
    if (huge.length && !STOP) {
      log('Крупные файлы (' + huge.length + ' шт, >700 МБ) сохраняю отдельными файлами…');
      for (const p of huge) {
        if (STOP) break;
        log('  ⬇ ' + p + ' (' + human(sizeOf(p)) + ')…');
        progShow('⬇ крупный файл: ' + p.split('/').pop(), 0, true);
        const ok = await saveOne(p, signal);
        if (ok) done++; else if (!STOP) bad++;
      }
    }
    await Promise.all(Array.from({ length: WORKERS }, worker));
    if (STOP) { progHide(); log('ОСТАНОВЛЕНО: скачивание отменено, ничего не сохранено.'); }
    else {
      await flush();
      log('ГОТОВО за ' + ((Date.now() - t0) / 1000).toFixed(1) + ' с: ' + done + ' файлов, ошибок ' + bad + ', архивов ' + (part - 1) + '.', 'ok');
      if (part - 1 > 1) log('Архивы распакуйте в ОДНУ папку.');
      progDone('ГОТОВО: ' + done + ' файлов, архивов ' + (part - 1) + (bad ? ', ошибок ' + bad : ''));
    }
    busy = false; runAC = null; $('#stop').style.display = 'none';
    stat(); updateMem();
  };

  /* ------------------------------ СКАЧАТЬ КАК ЕСТЬ ------------------------- */
  $('#goRaw').onclick = async () => {
    if (busy) { log('Уже идёт скачивание.'); return; }
    const list = visible().filter(p => SEL.has(p) && urlFor(p));
    if (!list.length) { log('Ничего не отмечено или нет ссылок.'); return; }
    if (list.length > 30 && !confirm('Скачать ' + list.length + ' файлов по отдельности, в родных форматах?\nБраузер спросит разрешение на множественное скачивание — разрешите его.')) return;
    busy = true; STOP = false; runAC = newAbort(); $('#stop').style.display = '';
    progShow('подготовка…', 0, true);
    const { sz } = selSize(list);
    log('СКАЧИВАЮ КАК ЕСТЬ: ' + list.length + ' файлов' + (sz ? ', ~' + human(sz) : '') + ', в родных форматах (без ZIP)…');
    if (list.length > 1) log('Разрешите браузеру множественное скачивание, когда спросит.');
    let done = 0, bad = 0;
    for (const p of list) {
      if (STOP) break;
      progShow('сохраняю ' + (done + bad + 1) + ' из ' + list.length + ': ' + p.split('/').pop(), (done + bad) / list.length * 100);
      const ok = await saveOne(p, runAC.signal);
      if (ok) done++; else if (!STOP) { bad++; if (bad < 6) log('  ошибка: ' + p); }
      if (!STOP && done % 10 === 0) log('  …' + done + '/' + list.length);
      if (!STOP) await new Promise(r => setTimeout(r, 250));
    }
    if (STOP) { progHide(); log('ОСТАНОВЛЕНО: отменено, несохранённые файлы не скачивались.'); }
    else { log('ГОТОВО: сохранено как есть ' + done + ' файлов, ошибок ' + bad + '.', 'ok'); progDone('ГОТОВО: сохранено ' + done + ' файлов'); }
    busy = false; runAC = null; $('#stop').style.display = 'none';
  };

  /* ------------------------------ НАСТРОЙКИ -------------------------------- */
  $('#openQ').onclick = () => window.open('https://chat.qwen.ai', '_blank', 'noopener');
  $('#openZ').onclick = () => window.open('https://chat.z.ai', '_blank', 'noopener');
  function fontMode() { const v = UI.font; return (v === 'small' || v === 'medium') ? v : 'big'; }
  function applyFontMode() {
    try {
      const m = fontMode();
      P.classList.toggle('wzrFontSm', m === 'small');
      P.classList.toggle('wzrFontMd', m === 'medium');
    } catch (e) {}
  }
  applyFontMode();
  $('#fsMode').value = fontMode();
  function applyFontNow(v) {
    UI.font = (v === 'small' || v === 'medium') ? v : 'big';
    saveUI();
    applyFontMode();
    try { renderTree(); } catch (e) {}      // список сразу пересчитывает строки
    fitHeight();
  }
  $('#fsMode').onchange = e => applyFontNow(e.target.value);
  $('#fsMode').oninput = e => applyFontNow(e.target.value);
  $('#szMode').value = UI.sizesMode || 'full';
  $('#szMode').onchange = e => {
    UI.sizesMode = e.target.value || 'full'; saveUI(); applySizesMode(true);
  };
  applySizesMode(false);
  $('#quotaGB').value = UI.quotaGB || 0;
  $('#quotaGB').onchange = e => { UI.quotaGB = Math.max(0, +e.target.value || 0); saveUI(); updateMem(); };
  $('#szNow').onclick = () => resolveSizes(true);

  function diagJson() {
    pollPerf();
    return JSON.stringify({
      app: 'Workspace Rescue V1', build: WZR_BUILD, host: HOST, path: location.pathname,
      zai: { mode: zaiMode, id: zaiId, wsId: zaiWsId, diag: zaiDiag },
      qwen: IS_QWEN, paths: PATHS.length, selected: SEL.size,
      sizesKnown: SIZEMAP.size, sizesUnknown: NEG.size,
      template: TEMPLATE, quota: quotaHint, bridge: HAS_BRIDGE, zipWorker: !!zipWorker, ui: UI,
      sources: [...captured.keys()].slice(0, 60),
      shapes: [...captured.entries()].slice(0, 14).map(([src2, json]) => ({
        src: src2.slice(0, 140),
        keys: (function sh(n, d) {
          if (d > 2 || n === null || typeof n !== 'object') return typeof n;
          if (Array.isArray(n)) return [sh(n[0], d + 1)];
          const o = {}; for (const k of Object.keys(n).slice(0, 14)) o[k] = sh(n[k], d + 1); return o;
        })(json, 0)
      })),
      lastRequests: reqLog.slice(-60),
      extraUrls: extraUrls.slice(-30),
      logTail: L.slice(-80)
    }, null, 1);
  }
  $('#runDiag').onclick = () => {
    setTab('main');
    log('— ДИАГНОСТИКА (V1) —');
    const withUrl = PATHS.filter(p => urlFor(p)).length;
    log('✓ Сайт: ' + HOST + (IS_QWEN ? ' (пресет Qwen)' : IS_ZAI ? ' (пресет Z.ai)' : ' (авторежим)'));
    log((qid() ? '✓' : '!') + ' Чат: ' + (qid() ? qid().slice(0, 13) + '…' : 'не определён (откройте страницу чата)'));
    log((PATHS.length ? '✓' : '✗') + ' Файлов в списке: ' + PATHS.length + ' (со ссылками: ' + withUrl + ')');
    log((HAS_BRIDGE ? '✓' : '!') + ' Мост расширения (обход CORS): ' + (HAS_BRIDGE ? 'подключён' : 'не подключён — режим консоли, часть CDN-файлов может не скачаться'));
    log((zipWorker ? '✓' : '!') + ' Фоновая сборка ZIP (Web Worker): ' + (zipWorker ? 'работает' : 'недоступна (CSP сайта) — ZIP собирается в основном потоке'));
    if (IS_ZAI) log((zaiToken() ? '✓' : '✗') + ' Токен z.ai: ' + (zaiToken() ? 'найден' : 'НЕТ — войдите в аккаунт'));
    log((TEMPLATE || IS_QWEN || IS_ZAI ? '✓' : '✗') + ' Шаблон ссылки: ' + (TEMPLATE ? 'пойман' : ((IS_QWEN || IS_ZAI) ? 'не нужен (пресет)' : 'не пойман — нажмите ПОЙМАТЬ ССЫЛКУ')));
    log((SIZEMAP.size || !PATHS.length ? '✓' : '!') + ' Размеры: известны у ' + SIZEMAP.size + ' из ' + PATHS.length + (NEG.size ? ' (не удалось определить: ' + NEG.size + ')' : ''));
    const total = UI.quotaGB > 0 ? UI.quotaGB + ' ГБ (из настроек)' : ((quotaHint && quotaHint.total) ? human(quotaHint.total) + ' (из API сайта)' : 'не определён — можно задать в Настройках');
    log('• Общий объём области: ' + total);
    log('• Панель: ' + (UI.dock ? 'закреплена ' + (UI.dock === 'right' ? 'справа' : 'слева') : 'плавающая') + ', ширина ' + Math.round(P.getBoundingClientRect().width) + ' px');
    const errs = L.filter(x => /ОШИБКА|✗|не удалось/i.test(x)).slice(-5);
    if (errs.length) { log('! Последние ошибки:'); for (const e of errs) log('    ' + e); }
    else log('✓ Ошибок в логе нет.');
    log('— конец диагностики —');
    copyText(diagJson(), 'Диагностика выполнена: результат в логе выше, полный отчёт скопирован в буфер обмена.');
  };
  $('#copylog').onclick = () => copyText(L.join('\n') + '\n\nTEMPLATE=' + TEMPLATE, 'Лог скопирован. Вставляйте ассистенту.');

  /* ------------------------------- авто-режимы ----------------------------- */
  addEventListener('wzr:show', () => {
    UI.hidden = false; saveUI();               // вернули вручную — пусть снова открывается после F5
    P.style.display = 'flex';                  // ВАЖНО: '' стирает display:flex и панель «оседает» блоком
    applyDock();
    fitHeight();
  });
  /* Автообновление: 30 с и только когда панель видна и ничего не качается —
     лишние запросы к API на z.ai приводили к ответам 429. */
  const iTimerRefresh = setInterval(() => {
    if (DEAD) return;
    if (busy || document.hidden || !panelVisible()) return;
    idle(() => { if (!busy) refresh(true); });
  }, 30000);

  /* Смена чата: всё, что накопилось по прошлому чату, не должно переезжать в
     новый. Раньше чистились только размеры и ссылки, поэтому в дереве оставались
     файлы предыдущего чата (а перехваченный трафик и кэш превью продолжали
     держать память). Теперь сбрасываем состояние целиком. */
  function resetForNewChat() {
    SIZEMAP.clear(); SIZE_BY_NAME.clear(); NEG.clear(); URLMAP.clear(); quotaHint = null;
    captured.clear(); capBytes = 0; scannedSrc.clear(); DISC_PATHS.clear();
    HARVEST.clear(); harvestSeen.clear();
    extraUrls.length = 0; cursors.discover = 0; cursors.harvest = 0;
    perfSeen.clear(); perfIdx = 0;
    blobs.clear();
    for (const u of prevCache.values()) { try { URL.revokeObjectURL(u); } catch (e) {} }
    prevCache.clear(); prevHide();
    KNOWN.clear(); SEL.clear(); OPEN_DIRS.clear();
    firstRender = true; curDirSizes = new Map(); TREE_LIMIT = 0;
    PATH_IDX_GEN++;
  }

  let lastPath = location.pathname;
  const iTimerChat = setInterval(() => {
    if (DEAD) return;
    if (location.pathname !== lastPath) {
      const oldQid = (lastPath.match(/\/[cs]\/([0-9a-f-]{8,})/i) || [])[1];
      lastPath = location.pathname;
      if (oldQid !== qid()) resetForNewChat();      // другой чат — файлы прошлого не показываем
      log('Переход в другой чат — обновляю список автоматически.');
      refresh(false);
    }
  }, 1500);

  /* --------------------------------- старт --------------------------------- */
  if (IS_ZAI) setZaiTarget();        // режим z.ai нужен сразу, а не после первого списка
  applySortLabel();
  applyDock();
  /* сборка сменилась (или её ещё не записали) — показываем панель, даже если её закрывали */
  if (UI.build !== WZR_BUILD) { UI.hidden = false; UI.build = WZR_BUILD; saveUI(); }
  if (UI.hidden) { P.style.display = 'none'; setPageMargin(0); }   // её закрыли в прошлый раз
  setTab(UI.tab === 'set' ? 'set' : 'main');
  window.dispatchEvent(new CustomEvent('wzr:ping'));   // спрашиваем мост расширения
  refresh(false);
  /* журнал показывает только дело: обновления, сохранения, ошибки */})();
