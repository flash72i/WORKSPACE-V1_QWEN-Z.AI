/* Фоновая служба расширения (Manifest V3).
   1) Клик по иконке — внедрить/показать панель на chat.qwen.ai и chat.z.ai.
   2) Релей запросов мимо CORS: страница просит байты по CDN-ссылке, фон качает
      их с правами host_permissions и возвращает base64. Крупные файлы качаются
      кусками (Range) — иначе один файл не влез бы в одно сообщение.
   3) Релей «узнать размер» (HEAD, затем GET Range).
   4) Инъекция по запросу моста (bridge.js): восстановление закреплённой панели
      после F5 даже там, где CSP сайта не пропускает <script src="chrome-extension:…">.

   Совместимость (Chrome 111+, Яндекс Браузер и др. Chromium):
   если executeScript с world:"MAIN" не поддерживается — запасной способ:
   внедрение <script src=chrome-extension://…/content.js> (web_accessible_resources). */

const SITE_RE = /^https:\/\/(chat\.qwen\.ai|chat\.z\.ai)\//;   // страницы, с которых принимаем сообщения
const MAX_INLINE = 48 * 1024 * 1024;                          // предел одного сообщения, байт
const TIMEOUT_SIZE = 15000, TIMEOUT_BYTES = 180000;
const MSG_TYPES = ['wzr-size', 'wzr-fetch', 'wzr-inject'];

/* События DOM доступны любому скрипту страницы: права расширения ограничиваем здесь. */
function allowedCdnUrl(value) {
  try {
    const url = new URL(value);
    return url.protocol === 'https:' && !url.username && !url.password &&
      (!url.port || url.port === '443') &&
      (url.hostname === 'cdn.qwenlm.ai' || url.hostname === 'alicdn.com' || url.hostname.endsWith('.alicdn.com'));
  } catch (e) { return false; }
}

/* Вместо файла сервер может отдать JSON-ошибку или HTML-заглушку: по такому
   content-type размер файла не считаем (иначе у всех файлов был бы один размер). */
function plausibleType(contentType, path) {
  if (!contentType) return true;
  const ct = contentType.toLowerCase();
  if (ct.includes('json')) return /\.(json|ipynb|webmanifest)$/i.test(path);
  if (ct.includes('text/html')) return /\.(html?|xhtml)$/i.test(path);
  if (ct.includes('text/plain') && /\.(png|jpe?g|gif|webp|zip|pdf|mp4|mp3)/i.test(path)) return false;
  return true;
}

/* «bytes=0-1023» → { header, start, end }. Строку собирает сам фон, поэтому
   принимаем только строгий формат и ограничиваем размер куска. */
function parseRange(value) {
  if (typeof value !== 'string') return null;
  const m = /^bytes=(\d{1,15})-(\d{1,15})$/.exec(value.trim());
  if (!m) return null;
  const start = Number(m[1]), end = Number(m[2]);
  if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end)) return null;
  if (end < start || end - start + 1 > MAX_INLINE) return null;
  return { header: 'bytes=' + start + '-' + end, start, end };
}
function totalFromContentRange(cr) {
  const m = cr && /bytes\s+\d+-\d+\/(\d+)\s*$/i.exec(cr);
  return m ? +m[1] : null;
}
function toB64(u8) {
  const CH = 0x8000; let bin = '';
  for (let i = 0; i < u8.length; i += CH) bin += String.fromCharCode.apply(null, u8.subarray(i, i + CH));
  return btoa(bin);
}

/* --- инъекция панели в MAIN-мир страницы --- */
function injectViaTag(src) {
  /* защита от двойной установки — внутри самого content.js (по номеру сборки) */
  const s = document.createElement('script');
  s.src = src;
  s.onload = () => s.remove();
  s.onerror = () => s.remove();
  (document.head || document.documentElement).appendChild(s);
}
/* Панель уже стоит на этой странице? Спрашиваем сам MAIN-мир страницы:
   повторное внедрение не нужно (иначе в консоли появлялось предупреждение
   «WORKSPACE V1 уже установлен», а панель пересобиралась на пустом месте). */
async function panelInstalled(tabId) {
  try {
    const [r] = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: () => !!window.__wzrBuild });
    return !!(r && r.result);
  } catch (e) { return false; }   // браузер без world:"MAIN" — считаем, что не установлена
}
async function injectInto(tabId) {
  if (tabId == null) return false;
  try {
    // мост (изолированный мир) — идемпотентно: внутри есть защита от двойной установки
    await chrome.scripting.executeScript({ target: { tabId }, files: ['bridge.js'] });
  } catch (e) { /* страница не готова — не страшно */ }
  if (await panelInstalled(tabId)) return true;   // панель уже есть — второй раз не внедряем
  try {
    // основной скрипт в MAIN-мире (идемпотентно: внутри защита window.__wzrBuild)
    try {
      await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'], world: 'MAIN' });
    } catch (e) {
      // запасной путь для браузеров без world:"MAIN" и для строгого CSP
      await chrome.scripting.executeScript({ target: { tabId }, func: injectViaTag, args: [chrome.runtime.getURL('content.js')] });
    }
    return true;
  } catch (e) { return false; }
}

/* --- клик по иконке: панель на текущей вкладке --- */
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab || tab.id == null || !SITE_RE.test(tab.url || '')) return;
  await injectInto(tab.id);
  try { await chrome.tabs.sendMessage(tab.id, { type: 'wzr-show' }); } catch (e) { /* вкладка уже ушла */ }
});

/* --- запросы страницы --- */
chrome.runtime.onMessage.addListener((m, sender, sendResponse) => {
  if (!m || MSG_TYPES.indexOf(m.type) < 0) return;
  if (!sender || sender.id !== chrome.runtime.id || !SITE_RE.test(sender.url || '')) {
    sendResponse({ ok: false, err: 'Недопустимый источник' });
    return;
  }

  /* восстановление панели после F5 (запрос от моста) */
  if (m.type === 'wzr-inject') {
    /* проверит страницу сама: если панель уже стоит — второй раз не внедряет */
    injectInto(sender.tab && sender.tab.id).then(ok => sendResponse({ ok }), () => sendResponse({ ok: false }));
    return true;   // ответ асинхронный
  }

  if (!allowedCdnUrl(m.url)) {
    sendResponse({ ok: false, err: 'Недопустимый адрес CDN' });
    return;
  }

  /* --- узнать размер файла по CDN-ссылке (HEAD, затем GET Range) --- */
  if (m.type === 'wzr-size') {
    const pth = String(m.url).split('?')[0];
    (async () => {
      try {
        let r = await fetch(m.url, { method: 'HEAD', credentials: 'omit', redirect: 'error', signal: AbortSignal.timeout(TIMEOUT_SIZE) });
        if (r.ok && plausibleType(r.headers.get('content-type'), pth)) {
          const cl = +(r.headers.get('content-length') || 0);
          if (r.headers.has('content-length') && Number.isSafeInteger(cl) && cl >= 0) { sendResponse({ ok: true, size: cl }); return; }
        }
        r = await fetch(m.url, { method: 'GET', credentials: 'omit', redirect: 'error', signal: AbortSignal.timeout(TIMEOUT_SIZE), headers: { Range: 'bytes=0-0' } });
        const cr = r.headers.get('content-range');
        const ct = r.headers.get('content-type');
        try { if (r.body) await r.body.cancel(); } catch (e) {}
        if (r.ok && plausibleType(ct, pth)) {
          const total = totalFromContentRange(cr);
          if (total != null) { sendResponse({ ok: true, size: total }); return; }
          const cl2 = +(r.headers.get('content-length') || 0);
          if (r.status !== 206 && cl2 > 0) { sendResponse({ ok: true, size: cl2 }); return; }
        }
        sendResponse({ ok: false, status: r.status });
      } catch (e) { sendResponse({ ok: false, err: String(e) }); }
    })();
    return true;   // ответ асинхронный
  }

  /* --- скачать байты мимо CORS (целиком или куском через Range) --- */
  if (m.type !== 'wzr-fetch') return;
  let range = null;
  if (m.range != null) {
    range = parseRange(m.range);
    if (!range) { sendResponse({ ok: false, err: 'Недопустимый диапазон' }); return; }
  }
  (async () => {
    try {
      const init = { credentials: 'omit', redirect: 'error', signal: AbortSignal.timeout(TIMEOUT_BYTES) };
      if (range) init.headers = { Range: range.header };
      const r = await fetch(m.url, init);
      if (!r.ok) { sendResponse({ ok: false, status: r.status }); return; }
      const cr = r.headers.get('content-range');
      const total = totalFromContentRange(cr);
      const u = new Uint8Array(await r.arrayBuffer());
      if (range && r.status !== 206) {
        // сервер проигнорировал Range и начал отдавать файл целиком
        sendResponse({ ok: false, rangeIgnored: true, status: r.status, size: u.length, total });
        return;
      }
      if (u.length > MAX_INLINE) {
        // одним сообщением такой кусок не отдать — просим качать по частям
        sendResponse({ ok: false, tooBig: true, size: u.length, total });
        return;
      }
      sendResponse({ ok: true, b64: toB64(u), partial: r.status === 206, size: u.length, total });
    } catch (e) {
      sendResponse({ ok: false, err: String(e) });
    }
  })();
  return true;   // ответ асинхронный
});
